﻿namespace PInterface
{
    partial class ListePlatsCuisinier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewPlats = new DataGridView();
            buttonAjouterPlat = new Button();
            buttonRetour = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlats).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewPlats
            // 
            dataGridViewPlats.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPlats.Location = new Point(41, 108);
            dataGridViewPlats.Name = "dataGridViewPlats";
            dataGridViewPlats.RowHeadersWidth = 51;
            dataGridViewPlats.Size = new Size(557, 299);
            dataGridViewPlats.TabIndex = 0;
            // 
            // buttonAjouterPlat
            // 
            buttonAjouterPlat.Location = new Point(675, 171);
            buttonAjouterPlat.Name = "buttonAjouterPlat";
            buttonAjouterPlat.Size = new Size(121, 29);
            buttonAjouterPlat.TabIndex = 1;
            buttonAjouterPlat.Text = "ajouter un plat";
            buttonAjouterPlat.UseVisualStyleBackColor = true;
            buttonAjouterPlat.Click += buttonAjouterPlat_Click;
            // 
            // buttonRetour
            // 
            buttonRetour.Location = new Point(12, 12);
            buttonRetour.Name = "buttonRetour";
            buttonRetour.Size = new Size(94, 29);
            buttonRetour.TabIndex = 2;
            buttonRetour.Text = "Retour";
            buttonRetour.UseVisualStyleBackColor = true;
            buttonRetour.Click += buttonRetour_Click;
            // 
            // ListePlatsCuisinier
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(866, 483);
            Controls.Add(buttonRetour);
            Controls.Add(buttonAjouterPlat);
            Controls.Add(dataGridViewPlats);
            Name = "ListePlatsCuisinier";
            Text = "ListePlatsCuisinier";
            Load += ListePlatsCuisinier_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlats).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewPlats;
        private Button buttonAjouterPlat;
        private Button buttonRetour;
    }
}