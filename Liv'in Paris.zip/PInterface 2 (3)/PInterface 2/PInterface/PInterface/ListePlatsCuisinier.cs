﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using static PInterface.Connexion_Cuisinier;

namespace PInterface
{
    /// <summary>
    /// Formulaire affichant la liste des plats d'un cuisinier.
    /// </summary>
    public partial class ListePlatsCuisinier : Form
    {
        private string connectionString = "Server=localhost;Database=projetSQL;Uid=root;Pwd=root;";
        private string pseudoCuisinier;

        /// <summary>
        /// Initialise une nouvelle instance de la classe ListePlatsCuisinier.
        /// </summary>
        public ListePlatsCuisinier()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Gère l'événement de chargement du formulaire.
        /// </summary>
        /// <param name="sender">La source de l'événement.</param>
        /// <param name="e">Les données de l'événement.</param>
        private void ListePlatsCuisinier_Load(object sender, EventArgs e)
        {
            AfficherPlats();
        }

        /// <summary>
        /// Affiche les plats associés au cuisinier connecté.
        /// </summary>
        private void AfficherPlats()
        {
            string pseudoCuisinier = SessionManager.PseudoConnecte;

            if (string.IsNullOrEmpty(pseudoCuisinier))
            {
                MessageBox.Show("Aucun cuisinier connecté.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = "SELECT p.id_plat, p.nom_plat, p.prix, p.date_fabrication, p.date_peremption, p.quantite " +
                           "FROM Plat p WHERE p.pseudo_cuisinier = @PseudoCuisinier";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                da.SelectCommand.Parameters.AddWithValue("@PseudoCuisinier", pseudoCuisinier);

                DataTable dt = new DataTable();

                try
                {
                    da.Fill(dt);

                    dataGridViewPlats.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la récupération des plats : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Gère l'événement de clic sur le bouton pour ajouter un plat.
        /// </summary>
        /// <param name="sender">La source de l'événement.</param>
        /// <param name="e">Les données de l'événement.</param>
        private void buttonAjouterPlat_Click(object sender, EventArgs e)
        {
            this.Hide();
            AjoutPlat ajoutPlatForm = new AjoutPlat(pseudoCuisinier);
            ajoutPlatForm.Show();
        }

        /// <summary>
        /// Gère l'événement de clic sur le bouton pour revenir à la page précédente.
        /// </summary>
        /// <param name="sender">La source de l'événement.</param>
        /// <param name="e">Les données de l'événement.</param>
        private void buttonRetour_Click(object sender, EventArgs e)
        {
            this.Hide();
            Graphe_Plat graphePlatForm = new Graphe_Plat();
            graphePlatForm.Show();
        }
    }
}
