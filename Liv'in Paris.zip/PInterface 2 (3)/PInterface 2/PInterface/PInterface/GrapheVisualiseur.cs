﻿using System.Drawing;

namespace projet
{
    /// <summary>
    /// Classe responsable de la visualisation d'un graphe de stations.
    /// </summary>
    public class VisualiseurGraphe
    {
        private Graphe _graphe;
        private float _zoom;
        private PointF _translation;

        /// <summary>
        /// Initialise une nouvelle instance de la classe VisualiseurGraphe.
        /// </summary>
        /// <param name="graphe">Le graphe à visualiser.</param>
        /// <param name="zoom">Le niveau de zoom pour la visualisation.</param>
        /// <param name="translation">La translation pour la visualisation.</param>
        public VisualiseurGraphe(Graphe graphe, float zoom, PointF translation)
        {
            _graphe = graphe;
            _zoom = zoom;
            _translation = translation;
        }

        /// <summary>
        /// Dessine le graphe sur un objet Graphics.
        /// </summary>
        /// <param name="g">L'objet Graphics sur lequel dessiner.</param>
        public void Dessiner(Graphics g)
        {
            g.TranslateTransform(_translation.X, _translation.Y);
            g.ScaleTransform(_zoom, _zoom);
            DessinerLignes(g);
            DessinerNoeuds(g);
        }

        /// <summary>
        /// Dessine les lignes entre les nœuds du graphe.
        /// </summary>
        /// <param name="g">L'objet Graphics sur lequel dessiner.</param>
        private void DessinerLignes(Graphics g)
        {
            foreach (var noeud in _graphe.Noeuds)
            {
                foreach (var ligne in noeud.Station.Lignes)
                {
                    var stationSuivante = _graphe.Noeuds.Find(n => n.Station.Nom == ligne);
                    if (stationSuivante != null)
                    {
                        Pen pen = new Pen(ObtenirCouleurLigne(noeud.Station.Ligne), 25);
                        g.DrawLine(pen, noeud.Position, stationSuivante.Position);
                    }
                }
            }
        }

        /// <summary>
        /// Dessine les nœuds du graphe.
        /// </summary>
        /// <param name="g">L'objet Graphics sur lequel dessiner.</param>
        private void DessinerNoeuds(Graphics g)
        {
            foreach (var noeud in _graphe.Noeuds)
            {
                Brush couleurNoeud = Brushes.Gray; // Utiliser une couleur grise par défaut pour toutes les stations

                float tailleCercle = 80;
                g.FillEllipse(couleurNoeud, noeud.Position.X - tailleCercle / 2, noeud.Position.Y - tailleCercle / 2, tailleCercle, tailleCercle);
                g.DrawEllipse(Pens.Black, noeud.Position.X - tailleCercle / 2, noeud.Position.Y - tailleCercle / 2, tailleCercle, tailleCercle);

                string texte = noeud.Station.Nom;
                Font font = new Font("Arial", 8, FontStyle.Bold);
                SizeF tailleTexte = g.MeasureString(texte, font);

                while (tailleTexte.Width > tailleCercle - 4 || tailleTexte.Height > tailleCercle - 4)
                {
                    if (texte.Length > 3)
                        texte = texte.Substring(0, texte.Length - 1);
                    else
                        break;

                    tailleTexte = g.MeasureString(texte, font);
                }

                float texteX = noeud.Position.X - tailleTexte.Width / 2;
                float texteY = noeud.Position.Y - tailleTexte.Height / 2;

                g.DrawString(texte, font, Brushes.Black, texteX, texteY);
            }
        }

        /// <summary>
        /// Obtient la couleur associée à une ligne.
        /// </summary>
        /// <param name="nomLigne">Le nom de la ligne.</param>
        /// <returns>La couleur associée à la ligne.</returns>
        public Color ObtenirCouleurLigne(string nomLigne)
        {
            if (string.IsNullOrEmpty(nomLigne))
            {
                return Color.Gray;
            }

            string nomNormalise = NormaliserNomLigne(nomLigne);

            if (CouleursLignes.Couleurs.ContainsKey(nomLigne))
            {
                return CouleursLignes.Couleurs[nomLigne];
            }

            foreach (var key in CouleursLignes.Couleurs.Keys)
            {
                if (NormaliserNomLigne(key) == nomNormalise)
                {
                    return CouleursLignes.Couleurs[key];
                }
            }

            try
            {
                Color couleur = Color.FromName(nomLigne);
                if (couleur.A != 0)
                {
                    return couleur;
                }
            }
            catch
            {
            }

            return Color.Gray;
        }

        /// <summary>
        /// Normalise le nom d'une ligne pour la comparaison.
        /// </summary>
        /// <param name="nomLigne">Le nom de la ligne à normaliser.</param>
        /// <returns>Le nom normalisé de la ligne.</returns>
        private string NormaliserNomLigne(string nomLigne)
        {
            if (string.IsNullOrEmpty(nomLigne)) return string.Empty;

            string result = nomLigne.ToLowerInvariant().Trim();
            result = result.Replace("ligne ", "").Replace("line ", "");
            result = new string(result.Where(c => char.IsLetterOrDigit(c)).ToArray());

            return result;
        }
    }
}
