﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace PInterface
{
    public partial class Connexion_Cuisinier : Form
    {
        public Connexion_Cuisinier()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Classe statique SessionManager pour gérer la session de l'utilisateur connecté.
        /// Contient une propriété statique pour stocker le pseudo du cuisinier connecté.
        /// </summary>
        public static class SessionManager
        {
            public static string PseudoConnecte { get; set; } = "";
        }

        private string connectionString = "Server=localhost;Database=projetSQL;Uid=root;Pwd=root;";

        /// <summary>
        /// Événement déclenché lors de l'appui sur le bouton de connexion.
        /// Vérifie si les informations de connexion (pseudo et mot de passe) sont valides,
        /// et ouvre la fenêtre Graphe_Plat si la connexion est réussie.
        /// </summary>
        private void buttonConnexion_Click(object sender, EventArgs e)
        {
            string pseudo = textPseudoC.Text.Trim();
            string mdp = textMDPC.Text.Trim();

            if (string.IsNullOrEmpty(pseudo) || string.IsNullOrEmpty(mdp))
            {
                MessageBox.Show("Veuillez remplir tous les champs.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT c.pseudo_cuisinier FROM Cuisinier c " +
                                   "JOIN Individu i ON c.telephone = i.telephone " +
                                   "WHERE c.pseudo_cuisinier = @Pseudo AND i.Mot_de_passe = @MDP";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Pseudo", pseudo);
                        cmd.Parameters.AddWithValue("@MDP", mdp);

                        object result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            SessionManager.PseudoConnecte = pseudo;

                            MessageBox.Show("Connexion réussie !", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Hide();
                            Graphe_Plat commandeForm = new Graphe_Plat();
                            commandeForm.Show();
                        }
                        else
                        {
                            MessageBox.Show("Pseudo ou mot de passe incorrect.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la connexion : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Événement déclenché lors de l'appui sur le bouton d'accueil.
        /// Permet de revenir à la fenêtre d'accueil de connexion/inscription.
        /// </summary>
        private void buttonAccueil_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connex_Inscr loginForm = new Connex_Inscr();
            loginForm.Show();
        }

        /// <summary>
        /// Événement déclenché lors de l'appui sur le bouton d'inscription.
        /// Permet de passer à la fenêtre d'inscription du cuisinier.
        /// </summary>
        private void buttonInscription_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inscription_Cuisinier loginForm = new Inscription_Cuisinier();
            loginForm.Show();
        }


    }
}
