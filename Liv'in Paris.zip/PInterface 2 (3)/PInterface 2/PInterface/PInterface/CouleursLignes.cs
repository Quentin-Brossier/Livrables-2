﻿using System.Collections.Generic;
using System.Drawing;

namespace projet
{
    /// <summary>
    /// Classe statique qui contient une collection de couleurs pour les lignes.
    /// Utilisée pour associer un numéro de ligne à une couleur spécifique.
    /// </summary>
    public static class CouleursLignes
    {
        /// <summary>
        /// Dictionnaire qui associe un identifiant de ligne (sous forme de chaîne) à une couleur.
        /// </summary>
        public static readonly Dictionary<string, Color> Couleurs = new Dictionary<string, Color>
        {
            { "1", Color.Yellow },
            { "2", Color.Blue },
            { "3", Color.Green },
            { "4", Color.Magenta },
            { "5", Color.Orange },
            { "6", Color.LightGreen },
            { "7", Color.Pink },
            { "8", Color.Purple },
            { "9", Color.Gold },
            { "10", Color.LightBlue },
            { "11", Color.Brown },
            { "12", Color.DarkGreen },
            { "13", Color.Teal },
            { "14", Color.Violet }
        };
    }
}
