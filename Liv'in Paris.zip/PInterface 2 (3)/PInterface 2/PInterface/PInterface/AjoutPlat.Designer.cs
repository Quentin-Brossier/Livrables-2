﻿namespace PInterface
{
    partial class AjoutPlat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBoxNom = new TextBox();
            numericUpDownPrix = new NumericUpDown();
            label3 = new Label();
            dateTimePickerFabrication = new DateTimePicker();
            label4 = new Label();
            dateTimePickerPeremption = new DateTimePicker();
            label5 = new Label();
            numericUpDownQuantite = new NumericUpDown();
            label6 = new Label();
            label7 = new Label();
            textBoxRegime = new TextBox();
            label8 = new Label();
            textBoxOrigine = new TextBox();
            textBoxType = new TextBox();
            label9 = new Label();
            listBoxIngredients = new ListBox();
            textBoxIngredient = new TextBox();
            buttonAjouterIngredient = new Button();
            label10 = new Label();
            buttonAjouterPlat = new Button();
            buttonRetour = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDownPrix).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownQuantite).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(331, 21);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 0;
            label1.Text = "Liv'in Paris";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(102, 110);
            label2.Name = "label2";
            label2.Size = new Size(131, 20);
            label2.TabIndex = 1;
            label2.Text = "Nom de votre plat";
            // 
            // textBoxNom
            // 
            textBoxNom.Location = new Point(239, 107);
            textBoxNom.Name = "textBoxNom";
            textBoxNom.Size = new Size(150, 27);
            textBoxNom.TabIndex = 2;
            // 
            // numericUpDownPrix
            // 
            numericUpDownPrix.Location = new Point(239, 150);
            numericUpDownPrix.Name = "numericUpDownPrix";
            numericUpDownPrix.Size = new Size(150, 27);
            numericUpDownPrix.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(102, 152);
            label3.Name = "label3";
            label3.Size = new Size(122, 20);
            label3.TabIndex = 4;
            label3.Text = "Prix de votre plat";
            // 
            // dateTimePickerFabrication
            // 
            dateTimePickerFabrication.Location = new Point(239, 193);
            dateTimePickerFabrication.Name = "dateTimePickerFabrication";
            dateTimePickerFabrication.Size = new Size(250, 27);
            dateTimePickerFabrication.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 198);
            label4.Name = "label4";
            label4.Size = new Size(206, 20);
            label4.TabIndex = 6;
            label4.Text = "Date fabrication de votre plat";
            // 
            // dateTimePickerPeremption
            // 
            dateTimePickerPeremption.Location = new Point(239, 237);
            dateTimePickerPeremption.Name = "dateTimePickerPeremption";
            dateTimePickerPeremption.Size = new Size(250, 27);
            dateTimePickerPeremption.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(21, 242);
            label5.Name = "label5";
            label5.Size = new Size(212, 20);
            label5.TabIndex = 8;
            label5.Text = "Date péremption de votre plat";
            // 
            // numericUpDownQuantite
            // 
            numericUpDownQuantite.Location = new Point(239, 280);
            numericUpDownQuantite.Name = "numericUpDownQuantite";
            numericUpDownQuantite.Size = new Size(150, 27);
            numericUpDownQuantite.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(35, 282);
            label6.Name = "label6";
            label6.Size = new Size(198, 20);
            label6.TabIndex = 10;
            label6.Text = "Quantité de votre plat (en g)";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(85, 332);
            label7.Name = "label7";
            label7.Size = new Size(139, 20);
            label7.TabIndex = 11;
            label7.Text = "Régime alimentaire";
            // 
            // textBoxRegime
            // 
            textBoxRegime.Location = new Point(239, 329);
            textBoxRegime.Name = "textBoxRegime";
            textBoxRegime.Size = new Size(150, 27);
            textBoxRegime.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(94, 370);
            label8.Name = "label8";
            label8.Size = new Size(109, 20);
            label8.TabIndex = 13;
            label8.Text = "Origine du plat";
            // 
            // textBoxOrigine
            // 
            textBoxOrigine.Location = new Point(239, 367);
            textBoxOrigine.Name = "textBoxOrigine";
            textBoxOrigine.Size = new Size(150, 27);
            textBoxOrigine.TabIndex = 14;
            // 
            // textBoxType
            // 
            textBoxType.Location = new Point(239, 409);
            textBoxType.Name = "textBoxType";
            textBoxType.Size = new Size(150, 27);
            textBoxType.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(10, 412);
            label9.Name = "label9";
            label9.Size = new Size(223, 20);
            label9.TabIndex = 16;
            label9.Text = "Son type (plat pricipale, dessert)";
            // 
            // listBoxIngredients
            // 
            listBoxIngredients.FormattingEnabled = true;
            listBoxIngredients.Location = new Point(737, 220);
            listBoxIngredients.Name = "listBoxIngredients";
            listBoxIngredients.Size = new Size(150, 104);
            listBoxIngredients.TabIndex = 17;
            // 
            // textBoxIngredient
            // 
            textBoxIngredient.Location = new Point(737, 152);
            textBoxIngredient.Name = "textBoxIngredient";
            textBoxIngredient.Size = new Size(150, 27);
            textBoxIngredient.TabIndex = 18;
            // 
            // buttonAjouterIngredient
            // 
            buttonAjouterIngredient.Location = new Point(913, 152);
            buttonAjouterIngredient.Name = "buttonAjouterIngredient";
            buttonAjouterIngredient.Size = new Size(94, 29);
            buttonAjouterIngredient.TabIndex = 19;
            buttonAjouterIngredient.Text = "Ajouter";
            buttonAjouterIngredient.UseVisualStyleBackColor = true;
            buttonAjouterIngredient.Click += buttonAjouterIngredient_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(579, 155);
            label10.Name = "label10";
            label10.Size = new Size(144, 20);
            label10.TabIndex = 20;
            label10.Text = "Liste des ingrédients";
            // 
            // buttonAjouterPlat
            // 
            buttonAjouterPlat.Location = new Point(743, 388);
            buttonAjouterPlat.Name = "buttonAjouterPlat";
            buttonAjouterPlat.Size = new Size(144, 29);
            buttonAjouterPlat.TabIndex = 21;
            buttonAjouterPlat.Text = "Ajouter votre plat";
            buttonAjouterPlat.UseVisualStyleBackColor = true;
            buttonAjouterPlat.Click += buttonAjouterPlat_Click;
            // 
            // buttonRetour
            // 
            buttonRetour.Location = new Point(12, 12);
            buttonRetour.Name = "buttonRetour";
            buttonRetour.Size = new Size(94, 29);
            buttonRetour.TabIndex = 22;
            buttonRetour.Text = "Retour";
            buttonRetour.UseVisualStyleBackColor = true;
            buttonRetour.Click += buttonRetour_Click;
            // 
            // AjoutPlat
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1033, 481);
            Controls.Add(buttonRetour);
            Controls.Add(buttonAjouterPlat);
            Controls.Add(label10);
            Controls.Add(buttonAjouterIngredient);
            Controls.Add(textBoxIngredient);
            Controls.Add(listBoxIngredients);
            Controls.Add(label9);
            Controls.Add(textBoxType);
            Controls.Add(textBoxOrigine);
            Controls.Add(label8);
            Controls.Add(textBoxRegime);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(numericUpDownQuantite);
            Controls.Add(label5);
            Controls.Add(dateTimePickerPeremption);
            Controls.Add(label4);
            Controls.Add(dateTimePickerFabrication);
            Controls.Add(label3);
            Controls.Add(numericUpDownPrix);
            Controls.Add(textBoxNom);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AjoutPlat";
            Text = "AjoutPlat";
            Load += AjoutPlat_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDownPrix).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownQuantite).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBoxNom;
        private NumericUpDown numericUpDownPrix;
        private Label label3;
        private DateTimePicker dateTimePickerFabrication;
        private Label label4;
        private DateTimePicker dateTimePickerPeremption;
        private Label label5;
        private NumericUpDown numericUpDownQuantite;
        private Label label6;
        private Label label7;
        private TextBox textBoxRegime;
        private Label label8;
        private TextBox textBoxOrigine;
        private TextBox textBoxType;
        private Label label9;
        private ListBox listBoxIngredients;
        private TextBox textBoxIngredient;
        private Button buttonAjouterIngredient;
        private Label label10;
        private Button buttonAjouterPlat;
        private Button buttonRetour;
    }
}