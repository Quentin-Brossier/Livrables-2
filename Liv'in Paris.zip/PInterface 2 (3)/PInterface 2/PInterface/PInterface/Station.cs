﻿using CsvHelper.Configuration.Attributes;
using System.Collections.Generic;

namespace projet
{
    /// <summary>
    /// Représente une station avec des informations géographiques et de ligne.
    /// </summary>
    public class Station
    {
        /// <summary>
        /// Identifiant unique de la station.
        /// </summary>
        [Name("ID Station")]
        public int Id { get; set; }

        /// <summary>
        /// Nom de la station.
        /// </summary>
        [Name("Libelle station")]
        public string Nom { get; set; }

        /// <summary>
        /// Longitude géographique de la station.
        /// </summary>
        [Name("Longitude")]
        public double Longitude { get; set; }

        /// <summary>
        /// Latitude géographique de la station.
        /// </summary>
        [Name("Latitude")]
        public double Latitude { get; set; }

        /// <summary>
        /// Ligne principale à laquelle la station appartient.
        /// </summary>
        [Name("Libelle Line")]
        public string Ligne { get; set; }

        /// <summary>
        /// Liste des lignes auxquelles la station appartient.
        /// </summary>
        public List<string> Lignes { get; set; } = new List<string>();

        /// <summary>
        /// Temps de changement par défaut en minutes.
        /// </summary>
        public int TempsDeChangement { get; set; } = 5;
    }

    /// <summary>
    /// Représente une ligne de transport entre les stations.
    /// </summary>
    public class Ligne
    {
        /// <summary>
        /// Identifiant de la station associée à la ligne.
        /// </summary>
        [Name("Station Id")]
        public int IdStation { get; set; }

        /// <summary>
        /// Nom de la station associée à la ligne.
        /// </summary>
        [Name("Station")]
        public string NomStation { get; set; }

        /// <summary>
        /// Station précédente sur la ligne. Peut être null ou vide si la station est un début.
        /// </summary>
        [Name("Précédent")]
        public string Precedent { get; set; }

        /// <summary>
        /// Station suivante sur la ligne. Peut être null ou vide si la station est un terminus.
        /// </summary>
        [Name("Suivant")]
        public string Suivant { get; set; }

        /// <summary>
        /// Temps entre deux stations en minutes.
        /// </summary>
        [Name("Temps entre 2 stations")]
        public int? TempsEntreStations { get; set; }

        /// <summary>
        /// Temps de changement en minutes.
        /// </summary>
        [Name("Temps de Changement")]
        public int? TempsDeChangement { get; set; }
    }
}
