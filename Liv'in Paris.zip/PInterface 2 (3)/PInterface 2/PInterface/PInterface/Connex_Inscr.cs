﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PInterface
{
    public partial class Connex_Inscr : Form
    {
        public Connex_Inscr()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connexion_Cuisinier loginForm = new Connexion_Cuisinier();
            loginForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connexion_Client loginForm = new Connexion_Client();
            loginForm.Show();
        }

        private void Connex_Inscr_Load(object sender, EventArgs e)
        {

        }
    }
}
