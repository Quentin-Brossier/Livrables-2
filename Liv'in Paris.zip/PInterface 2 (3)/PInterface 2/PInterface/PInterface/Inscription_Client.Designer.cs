﻿namespace PInterface
{
    partial class Inscription_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textStation = new TextBox();
            textNum = new TextBox();
            textCP = new TextBox();
            textVille = new TextBox();
            textRue = new TextBox();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            textTelephone = new TextBox();
            textMail = new TextBox();
            textMDP = new TextBox();
            textPrenom = new TextBox();
            textNom = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label11 = new Label();
            button1 = new Button();
            button2 = new Button();
            label12 = new Label();
            textPrefAlim = new TextBox();
            label13 = new Label();
            textPseudoClient = new TextBox();
            SuspendLayout();
            // 
            // textStation
            // 
            textStation.Location = new Point(586, 285);
            textStation.Name = "textStation";
            textStation.Size = new Size(125, 27);
            textStation.TabIndex = 40;
            // 
            // textNum
            // 
            textNum.Location = new Point(586, 247);
            textNum.Name = "textNum";
            textNum.Size = new Size(125, 27);
            textNum.TabIndex = 39;
            // 
            // textCP
            // 
            textCP.Location = new Point(586, 211);
            textCP.Name = "textCP";
            textCP.Size = new Size(125, 27);
            textCP.TabIndex = 38;
            // 
            // textVille
            // 
            textVille.Location = new Point(586, 179);
            textVille.Name = "textVille";
            textVille.Size = new Size(125, 27);
            textVille.TabIndex = 37;
            // 
            // textRue
            // 
            textRue.Location = new Point(586, 143);
            textRue.Name = "textRue";
            textRue.Size = new Size(125, 27);
            textRue.TabIndex = 36;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(324, 289);
            label10.Name = "label10";
            label10.Size = new Size(242, 20);
            label10.TabIndex = 35;
            label10.Text = "Station la plus proche de chez vous";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(503, 247);
            label9.Name = "label9";
            label9.Size = new Size(63, 20);
            label9.TabIndex = 34;
            label9.Text = "Numéro";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(477, 214);
            label8.Name = "label8";
            label8.Size = new Size(89, 20);
            label8.TabIndex = 33;
            label8.Text = "Code postal";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(528, 179);
            label7.Name = "label7";
            label7.Size = new Size(38, 20);
            label7.TabIndex = 32;
            label7.Text = "Ville";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(528, 146);
            label6.Name = "label6";
            label6.Size = new Size(34, 20);
            label6.TabIndex = 31;
            label6.Text = "Rue";
            // 
            // textTelephone
            // 
            textTelephone.Location = new Point(158, 279);
            textTelephone.Name = "textTelephone";
            textTelephone.Size = new Size(125, 27);
            textTelephone.TabIndex = 30;
            // 
            // textMail
            // 
            textMail.Location = new Point(158, 241);
            textMail.Name = "textMail";
            textMail.Size = new Size(125, 27);
            textMail.TabIndex = 29;
            // 
            // textMDP
            // 
            textMDP.Location = new Point(158, 208);
            textMDP.Name = "textMDP";
            textMDP.Size = new Size(125, 27);
            textMDP.TabIndex = 28;
            // 
            // textPrenom
            // 
            textPrenom.Location = new Point(158, 173);
            textPrenom.Name = "textPrenom";
            textPrenom.Size = new Size(125, 27);
            textPrenom.TabIndex = 27;
            // 
            // textNom
            // 
            textNom.Location = new Point(158, 140);
            textNom.Name = "textNom";
            textNom.Size = new Size(125, 27);
            textNom.TabIndex = 26;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(32, 282);
            label5.Name = "label5";
            label5.Size = new Size(78, 20);
            label5.TabIndex = 25;
            label5.Text = "Téléphone";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(32, 214);
            label4.Name = "label4";
            label4.Size = new Size(98, 20);
            label4.TabIndex = 24;
            label4.Text = "Mot de passe";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(32, 248);
            label3.Name = "label3";
            label3.Size = new Size(38, 20);
            label3.TabIndex = 23;
            label3.Text = "Mail";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 179);
            label2.Name = "label2";
            label2.Size = new Size(60, 20);
            label2.TabIndex = 22;
            label2.Text = "Prénom";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 146);
            label1.Name = "label1";
            label1.Size = new Size(42, 20);
            label1.TabIndex = 21;
            label1.Text = "Nom";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(503, 18);
            label11.Name = "label11";
            label11.Size = new Size(76, 20);
            label11.TabIndex = 41;
            label11.Text = "Liv'in Paris";
            // 
            // button1
            // 
            button1.Location = new Point(503, 365);
            button1.Name = "button1";
            button1.Size = new Size(150, 50);
            button1.TabIndex = 42;
            button1.Text = "Inscription";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(16, 12);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 43;
            button2.Text = "Retour";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(797, 153);
            label12.Name = "label12";
            label12.Size = new Size(158, 20);
            label12.TabIndex = 44;
            label12.Text = "Préférence alimentaire";
            // 
            // textPrefAlim
            // 
            textPrefAlim.Location = new Point(963, 146);
            textPrefAlim.Name = "textPrefAlim";
            textPrefAlim.Size = new Size(125, 27);
            textPrefAlim.TabIndex = 45;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(898, 182);
            label13.Name = "label13";
            label13.Size = new Size(57, 20);
            label13.TabIndex = 46;
            label13.Text = "Pseudo";
            // 
            // textPseudoClient
            // 
            textPseudoClient.Location = new Point(963, 182);
            textPseudoClient.Name = "textPseudoClient";
            textPseudoClient.Size = new Size(125, 27);
            textPseudoClient.TabIndex = 47;
            // 
            // Inscription_Client
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1133, 463);
            Controls.Add(textPseudoClient);
            Controls.Add(label13);
            Controls.Add(textPrefAlim);
            Controls.Add(label12);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label11);
            Controls.Add(textStation);
            Controls.Add(textNum);
            Controls.Add(textCP);
            Controls.Add(textVille);
            Controls.Add(textRue);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(textTelephone);
            Controls.Add(textMail);
            Controls.Add(textMDP);
            Controls.Add(textPrenom);
            Controls.Add(textNom);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Inscription_Client";
            Text = "Inscription_Client";
            Load += Inscription_Client_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textStation;
        private TextBox textNum;
        private TextBox textCP;
        private TextBox textVille;
        private TextBox textRue;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private TextBox textTelephone;
        private TextBox textMail;
        private TextBox textMDP;
        private TextBox textPrenom;
        private TextBox textNom;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label11;
        private Button button1;
        private Button button2;
        private Label label12;
        private TextBox textPrefAlim;
        private Label label13;
        private TextBox textPseudoClient;
    }
}