﻿using System.Drawing;

namespace projet
{
    /// <summary>
    /// Représente un lien entre deux nœuds dans un graphe.
    /// </summary>
    public class Lien
    {
        /// <summary>
        /// Obtient le premier nœud du lien.
        /// </summary>
        public Noeud Noeud1 { get; }

        /// <summary>
        /// Obtient le deuxième nœud du lien.
        /// </summary>
        public Noeud Noeud2 { get; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe Lien.
        /// </summary>
        /// <param name="noeud1">Le premier nœud du lien.</param>
        /// <param name="noeud2">Le deuxième nœud du lien.</param>
        public Lien(Noeud noeud1, Noeud noeud2)
        {
            this.Noeud1 = noeud1;
            this.Noeud2 = noeud2;
        }
    }
}
