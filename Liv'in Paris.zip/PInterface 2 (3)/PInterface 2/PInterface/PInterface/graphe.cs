﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CsvHelper;
using CsvHelper.Configuration;

namespace projet
{
    /// <summary>
    /// Classe représentant un graphe de stations avec des nœuds et des lignes.
    /// </summary>
    public class Graphe
    {
        /// <summary>
        /// Liste des nœuds représentant les stations.
        /// </summary>
        public List<Noeud> Noeuds { get; set; } = new List<Noeud>();

        /// <summary>
        /// Charge les stations depuis un fichier CSV.
        /// </summary>
        /// <param name="cheminFichier">Le chemin du fichier CSV contenant les stations.</param>
        public void ChargerStationsDepuisCSV(string cheminFichier)
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                Delimiter = ";",
                HeaderValidated = null,
                MissingFieldFound = null
            };

            try
            {
                using var reader = new StreamReader(cheminFichier, Encoding.UTF8);
                using var csv = new CsvReader(reader, config);
                var stations = csv.GetRecords<Station>();

                foreach (var station in stations)
                {
                    if (Noeuds.Any(n => n.Station.Id == station.Id))
                    {
                        continue;
                    }

                    PointF position = ConvertirCoordonnees(station.Latitude, station.Longitude);
                    Noeuds.Add(new Noeud(station, position));
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Erreur lors de la lecture du fichier CSV : {ex.Message}");
            }
        }

        /// <summary>
        /// Charge les lignes depuis un fichier CSV et établit les connexions entre les stations.
        /// </summary>
        /// <param name="cheminFichier">Le chemin du fichier CSV contenant les lignes.</param>
        public void ChargerLignesDepuisCSV(string cheminFichier)
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                Delimiter = ";",
                HeaderValidated = null,
                MissingFieldFound = null
            };

            var liensOrientes = new List<Tuple<string, string>>
            {
                new Tuple<string, string>("Javel - André Citroën", "Charles Michels"),
                new Tuple<string, string>("Eglise d'Auteuil", "Javel - André Citroën"),
                new Tuple<string, string>("Michel-Ange - Auteuil", "Eglise d'Auteuil"),
                new Tuple<string, string>("Porte d'Auteuil", "Michel-Ange - Auteuil"),
                new Tuple<string, string>("Michel-Ange - Molitor", "Porte d'Auteuil"),
                new Tuple<string, string>("Chardon Lagache", "Michel-Ange - Molitor"),
                new Tuple<string, string>("Mirabeau", "Chardon Lagache"),
                new Tuple<string, string>("Botzaris", "Buttes Chaumont"),
                new Tuple<string, string>("Place des Fêtes", "Botzaris"),
                new Tuple<string, string>("Pré-Saint-Gervais", "Place des Fêtes"),
                new Tuple<string, string>("Danube", "Pré-Saint-Gervais"),
                new Tuple<string, string>("Botzaris", "Danube")
            };

            try
            {
                using var reader = new StreamReader(cheminFichier, Encoding.UTF8);
                using var csv = new CsvReader(reader, config);
                var lignes = csv.GetRecords<Ligne>();

                foreach (var ligne in lignes)
                {
                    var station = Noeuds.Find(n => n.Station.Id == ligne.IdStation)?.Station;
                    if (station != null)
                    {
                        if (!string.IsNullOrEmpty(ligne.Suivant))
                        {
                            station.Lignes.Add(ligne.Suivant);
                        }
                        if (!string.IsNullOrEmpty(ligne.Precedent))
                        {
                            station.Lignes.Add(ligne.Precedent);
                        }
                    }
                }

                foreach (var noeud in Noeuds)
                {
                    foreach (var ligne in noeud.Station.Lignes)
                    {
                        var stationSuivante = Noeuds.Find(n => n.Station.Nom == ligne);
                        if (stationSuivante != null && !stationSuivante.Station.Lignes.Contains(noeud.Station.Nom))
                        {
                            var lien = new Tuple<string, string>(noeud.Station.Nom, stationSuivante.Station.Nom);
                            var lienInverse = new Tuple<string, string>(stationSuivante.Station.Nom, noeud.Station.Nom);

                            if (!liensOrientes.Contains(lien) && !liensOrientes.Contains(lienInverse))
                            {
                                stationSuivante.Station.Lignes.Add(noeud.Station.Nom);
                            }
                        }
                    }
                }

                foreach (var lien in liensOrientes)
                {
                    var stationDepart = Noeuds.Find(n => n.Station.Nom == lien.Item1)?.Station;
                    var stationArrivee = Noeuds.Find(n => n.Station.Nom == lien.Item2)?.Station;

                    if (stationDepart != null && stationArrivee != null)
                    {
                        if (!stationDepart.Lignes.Contains(stationArrivee.Nom))
                        {
                            stationDepart.Lignes.Add(stationArrivee.Nom);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Erreur lors de la lecture du fichier CSV des lignes : {ex.Message}");
            }
        }

        /// <summary>
        /// Trouve le plus court chemin entre deux stations en utilisant l'algorithme de Dijkstra.
        /// </summary>
        /// <param name="startStationName">Nom de la station de départ.</param>
        /// <param name="endStationName">Nom de la station d'arrivée.</param>
        /// <param name="closedStationName">Nom de la station fermée à éviter.</param>
        /// <param name="cheminNoeuds">Liste des nœuds du chemin trouvé.</param>
        /// <param name="cheminLignes">Liste des lignes du chemin trouvé.</param>
        public void Dijkstra(string startStationName, string endStationName, string closedStationName, out List<Noeud> cheminNoeuds, out List<Tuple<PointF, PointF>> cheminLignes)
        {
            cheminNoeuds = new List<Noeud>();
            cheminLignes = new List<Tuple<PointF, PointF>>();

            var startNode = Noeuds.FirstOrDefault(n => n.Station.Nom == startStationName);
            var endNode = Noeuds.FirstOrDefault(n => n.Station.Nom == endStationName);

            if (startNode == null || endNode == null)
            {
                throw new Exception("Stations de départ ou d'arrivée non trouvées.");
            }

            var distances = new Dictionary<Noeud, float>();
            var previous = new Dictionary<Noeud, Noeud>();
            var nodes = new List<Noeud>(Noeuds);

            foreach (var noeud in Noeuds)
            {
                distances[noeud] = noeud == startNode ? 0 : float.MaxValue;
            }

            const float distanceParMinute = 100; 
            const float distanceFermee = float.MaxValue / 2; 

            while (nodes.Count > 0)
            {
                var smallest = nodes.OrderBy(n => distances[n]).First();
                nodes.Remove(smallest);

                if (smallest == endNode)
                {
                    var path = new List<Noeud>();
                    while (previous.ContainsKey(smallest))
                    {
                        path.Add(smallest);
                        smallest = previous[smallest];
                    }
                    path.Add(startNode);
                    path.Reverse();

                    MettreEnEvidenceChemin(path, out cheminNoeuds, out cheminLignes);
                    return;
                }

                if (distances[smallest] == float.MaxValue)
                {
                    break;
                }

                foreach (var neighborName in smallest.Station.Lignes)
                {
                    var neighbor = Noeuds.FirstOrDefault(n => n.Station.Nom == neighborName);
                    if (neighbor == null) continue;

                    var alt = distances[smallest] + Distance(smallest.Position, neighbor.Position);
                    if (smallest.Station.Ligne != neighbor.Station.Ligne)
                    {
                        alt += smallest.Station.TempsDeChangement * distanceParMinute;
                    }
                    if (neighbor.Station.Nom == closedStationName)
                    {
                        alt += distanceFermee;
                    }
                    if (alt < distances[neighbor])
                    {
                        distances[neighbor] = alt;
                        previous[neighbor] = smallest;
                    }
                }
            }
        }

        /// <summary>
        /// Trouve le plus court chemin entre deux stations en utilisant l'algorithme de Bellman-Ford.
        /// </summary>
        /// <param name="startStationName">Nom de la station de départ.</param>
        /// <param name="endStationName">Nom de la station d'arrivée.</param>
        /// <param name="closedStationName">Nom de la station fermée à éviter.</param>
        /// <param name="cheminNoeuds">Liste des nœuds du chemin trouvé.</param>
        /// <param name="cheminLignes">Liste des lignes du chemin trouvé.</param>
        public void BellmanFord(string startStationName, string endStationName, string closedStationName, out List<Noeud> cheminNoeuds, out List<Tuple<PointF, PointF>> cheminLignes)
        {
            cheminNoeuds = new List<Noeud>();
            cheminLignes = new List<Tuple<PointF, PointF>>();

            var startNode = Noeuds.FirstOrDefault(n => n.Station.Nom == startStationName);
            var endNode = Noeuds.FirstOrDefault(n => n.Station.Nom == endStationName);

            if (startNode == null || endNode == null)
            {
                throw new Exception("Stations de départ ou d'arrivée non trouvées.");
            }

            var distances = new Dictionary<Noeud, float>();
            var previous = new Dictionary<Noeud, Noeud>();

            foreach (var noeud in Noeuds)
            {
                distances[noeud] = float.MaxValue;
                previous[noeud] = null;
            }
            distances[startNode] = 0;

            const float distanceParMinute = 100; 
            const float distanceFermee = float.MaxValue / 2; 

            for (int i = 0; i < Noeuds.Count - 1; i++)
            {
                foreach (var noeud in Noeuds)
                {
                    foreach (var neighborName in noeud.Station.Lignes)
                    {
                        var neighbor = Noeuds.FirstOrDefault(n => n.Station.Nom == neighborName);
                        if (neighbor == null) continue;

                        var alt = distances[noeud] + Distance(noeud.Position, neighbor.Position);
                        if (noeud.Station.Ligne != neighbor.Station.Ligne)
                        {
                            alt += noeud.Station.TempsDeChangement * distanceParMinute;
                        }
                        if (neighbor.Station.Nom == closedStationName)
                        {
                            alt += distanceFermee;
                        }
                        if (alt < distances[neighbor])
                        {
                            distances[neighbor] = alt;
                            previous[neighbor] = noeud;
                        }
                    }
                }
            }

            foreach (var noeud in Noeuds)
            {
                foreach (var neighborName in noeud.Station.Lignes)
                {
                    var neighbor = Noeuds.FirstOrDefault(n => n.Station.Nom == neighborName);
                    if (neighbor == null) continue;

                    var alt = distances[noeud] + Distance(noeud.Position, neighbor.Position);
                    if (noeud.Station.Ligne != neighbor.Station.Ligne)
                    {
                        alt += noeud.Station.TempsDeChangement * distanceParMinute;
                    }
                    if (neighbor.Station.Nom == closedStationName)
                    {
                        alt += distanceFermee;
                    }
                }
            }

            var path = new List<Noeud>();
            var currentNode = endNode;
            while (currentNode != null)
            {
                path.Add(currentNode);
                currentNode = previous[currentNode];
            }
            path.Reverse();

            MettreEnEvidenceChemin(path, out cheminNoeuds, out cheminLignes);
        }

        /// <summary>
        /// Met en évidence le chemin trouvé.
        /// </summary>
        /// <param name="chemin">Liste des nœuds du chemin.</param>
        /// <param name="cheminNoeuds">Liste des nœuds du chemin mis en évidence.</param>
        /// <param name="cheminLignes">Liste des lignes du chemin mis en évidence.</param>
        private void MettreEnEvidenceChemin(List<Noeud> chemin, out List<Noeud> cheminNoeuds, out List<Tuple<PointF, PointF>> cheminLignes)
        {
            cheminNoeuds = new List<Noeud>();
            cheminLignes = new List<Tuple<PointF, PointF>>();

            for (int i = 0; i < chemin.Count - 1; i++)
            {
                var noeud = chemin[i];
                var noeudSuivant = chemin[i + 1];
                cheminNoeuds.Add(noeud);
                cheminLignes.Add(new Tuple<PointF, PointF>(noeud.Position, noeudSuivant.Position));
            }
            cheminNoeuds.Add(chemin.Last());
        }

        /// <summary>
        /// Calcule la distance euclidienne entre deux points.
        /// </summary>
        /// <param name="point1">Premier point.</param>
        /// <param name="point2">Deuxième point.</param>
        /// <returns>Distance entre les deux points.</returns>
        public float Distance(PointF point1, PointF point2)
        {
            return (float)Math.Sqrt(Math.Pow(point1.X - point2.X, 2) + Math.Pow(point1.Y - point2.Y, 2));
        }

        /// <summary>
        /// Convertit les coordonnées géographiques en coordonnées cartésiennes.
        /// </summary>
        /// <param name="latitude">Latitude de la station.</param>
        /// <param name="longitude">Longitude de la station.</param>
        /// <returns>PointF représentant les coordonnées cartésiennes.</returns>
        public PointF ConvertirCoordonnees(double latitude, double longitude)
        {
            const double latitudeCentre = 48.8566;
            const double longitudeCentre = 2.3522;
            const double echelle = 35000;
            const float offsetX = 1000;
            const float offsetY = 300;

            float x = (float)((longitude - longitudeCentre) * echelle) + offsetX;
            float y = (float)((latitudeCentre - latitude) * echelle) + offsetY;

            return new PointF(x, y);
        }
    }
}
