﻿namespace PInterface
{
    partial class Graphe_Plat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            buttonRetour = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(335, 20);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 0;
            label1.Text = "Liv'in Paris";
            // 
            // button1
            // 
            button1.Location = new Point(28, 145);
            button1.Name = "button1";
            button1.Size = new Size(325, 255);
            button1.TabIndex = 1;
            button1.Text = "Voir le graphe";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(444, 145);
            button2.Name = "button2";
            button2.Size = new Size(325, 255);
            button2.TabIndex = 2;
            button2.Text = "Ajouter des plats à votre menu";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // buttonRetour
            // 
            buttonRetour.Location = new Point(12, 11);
            buttonRetour.Name = "buttonRetour";
            buttonRetour.Size = new Size(94, 29);
            buttonRetour.TabIndex = 3;
            buttonRetour.Text = "Retour";
            buttonRetour.UseVisualStyleBackColor = true;
            buttonRetour.Click += buttonRetour_Click;
            // 
            // Graphe_Plat
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonRetour);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "Graphe_Plat";
            Text = "AjoutPlat_Cuisinier";
            Load += Graphe_Plat_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private Button button2;
        private Button buttonRetour;
    }
}