﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PInterface
{
    public partial class Connexion_Client : Form
    {
        private string connectionString = "Server=localhost;Database=projetSQL;Uid=root;Pwd=root;";

        /// <summary>
        /// Constructeur de la classe Connexion_Client.
        /// Initialise le formulaire de connexion.
        /// </summary>
        public Connexion_Client()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Événement déclenché lors de l'appui sur le bouton de connexion.
        /// Vérifie si les informations de connexion sont correctes et ouvre la fenêtre Commande_Client si c'est le cas.
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            string pseudo = textPseudoCl.Text.Trim();
            string mdp = textMDPCl.Text.Trim();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT i.telephone FROM Individu i " +
                                   "JOIN Client_Individuel c ON i.telephone = c.telephone " +
                                   "WHERE c.pseudo_client = @Pseudo AND i.Mot_de_passe = @MDP";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Pseudo", pseudo);
                        cmd.Parameters.AddWithValue("@MDP", mdp);

                        object result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            MessageBox.Show("Connexion réussie !", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Hide();

                            Commande_Client commandeForm = new Commande_Client(pseudo);
                            commandeForm.Show();
                        }
                        else
                        {
                            MessageBox.Show("Pseudo ou mot de passe incorrect.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la connexion : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Événement déclenché lors de l'appui sur le bouton pour passer à l'inscription.
        /// Masque la fenêtre de connexion et affiche la fenêtre d'inscription.
        /// </summary>
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connex_Inscr loginForm = new Connex_Inscr();
            loginForm.Show();
        }

        /// <summary>
        /// Événement déclenché lors de l'appui sur le bouton pour s'inscrire.
        /// Masque la fenêtre de connexion et affiche la fenêtre d'inscription.
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inscription_Client loginForm = new Inscription_Client();
            loginForm.Show();
        }

        private void Connexion_Client_Load(object sender, EventArgs e)
        {

        }
    }
}
