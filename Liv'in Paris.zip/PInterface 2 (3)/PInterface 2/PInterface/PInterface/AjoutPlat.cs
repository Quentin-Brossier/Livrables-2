﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Transactions;
using System.Windows.Forms;
using static PInterface.Connexion_Cuisinier;

namespace PInterface
{
    public partial class AjoutPlat : Form
    {
        /// <summary>
        /// Constructeur de la classe AjoutPlat, initialise le formulaire
        /// </summary>
        public AjoutPlat(string pseudoCuisinier)
        {
            InitializeComponent();
        }

        /// <summary>
        /// Événement déclenché lors du chargement du formulaire. 
        /// Aucune action particulière n'est définie pour le moment.
        /// </summary>
        private void AjoutPlat_Load(object sender, EventArgs e)
        {
            // Vous pouvez ajouter des actions supplémentaires à l'occasion du chargement du formulaire
        }

        /// <summary>
        /// Chaîne de connexion à la base de données MySQL utilisée pour les opérations de base de données
        /// </summary>
        private string connectionString = "Server=localhost;Database=projetSQL;Uid=root;Pwd=root;";

        /// <summary>
        /// Événement déclenché lorsqu'un ingrédient est ajouté à la liste.
        /// Vérifie que l'ingrédient n'est pas vide, l'ajoute à la liste et vide la zone de texte.
        /// </summary>
        private void buttonAjouterIngredient_Click(object sender, EventArgs e)
        {
            string ingredient = textBoxIngredient.Text.Trim();
            if (!string.IsNullOrEmpty(ingredient))
            {
                listBoxIngredients.Items.Add(ingredient);
                textBoxIngredient.Clear();
            }
            else
            {
                MessageBox.Show("Veuillez entrer un ingrédient.");
            }
        }

        /// <summary>
        /// Événement déclenché lorsqu'un plat est ajouté. 
        /// Insère le plat et ses ingrédients dans la base de données.
        /// </summary>
        private void buttonAjouterPlat_Click(object sender, EventArgs e)
        {
            string nomPlat = textBoxNom.Text;
            decimal prix = numericUpDownPrix.Value;
            DateTime dateFabrication = dateTimePickerFabrication.Value;
            DateTime datePeremption = dateTimePickerPeremption.Value;
            decimal quantite = numericUpDownQuantite.Value;
            string regimeAlimentaire = textBoxRegime.Text;
            string origine = textBoxOrigine.Text;
            string typePlat = textBoxType.Text;
            string pseudoCuisinier = SessionManager.PseudoConnecte;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string queryRecette = "INSERT INTO Recette (regime_alimentaire, nationalite, type) " +
                                          "VALUES (@RegimeAlimentaire, @Origine, @TypePlat)";
                    using (MySqlCommand cmdRecette = new MySqlCommand(queryRecette, conn))
                    {
                        cmdRecette.Parameters.AddWithValue("@RegimeAlimentaire", regimeAlimentaire);
                        cmdRecette.Parameters.AddWithValue("@Origine", origine);
                        cmdRecette.Parameters.AddWithValue("@TypePlat", typePlat);

                        cmdRecette.ExecuteNonQuery();
                    }

                    string queryIdRecette = "SELECT LAST_INSERT_ID()";
                    int idRecette = -1;
                    using (MySqlCommand cmdIdRecette = new MySqlCommand(queryIdRecette, conn))
                    {
                        idRecette = Convert.ToInt32(cmdIdRecette.ExecuteScalar());
                    }

                    string queryPlat = "INSERT INTO Plat (nom_plat, prix, date_fabrication, date_peremption, quantite, pseudo_cuisinier, id_recette) " +
                                       "VALUES (@NomPlat, @Prix, @DateFabrication, @DatePeremption, @Quantite, @PseudoCuisinier, @IdRecette)";

                    using (MySqlCommand cmdPlat = new MySqlCommand(queryPlat, conn))
                    {
                        cmdPlat.Parameters.AddWithValue("@NomPlat", nomPlat);
                        cmdPlat.Parameters.AddWithValue("@Prix", prix);
                        cmdPlat.Parameters.AddWithValue("@DateFabrication", dateFabrication);
                        cmdPlat.Parameters.AddWithValue("@DatePeremption", datePeremption);
                        cmdPlat.Parameters.AddWithValue("@Quantite", quantite);
                        cmdPlat.Parameters.AddWithValue("@PseudoCuisinier", pseudoCuisinier);
                        cmdPlat.Parameters.AddWithValue("@IdRecette", idRecette);

                        cmdPlat.ExecuteNonQuery();
                    }

                    foreach (var item in listBoxIngredients.Items)
                    {
                        string nomIngredient = item.ToString().Trim();
                        int idIngredient = -1;

                        string queryCheckIngredient = "SELECT id_ingredient FROM Ingrédient WHERE nom_ingredient = @NomIngredient";
                        using (MySqlCommand cmdCheck = new MySqlCommand(queryCheckIngredient, conn))
                        {
                            cmdCheck.Parameters.AddWithValue("@NomIngredient", nomIngredient);
                            object result = cmdCheck.ExecuteScalar();

                            if (result != null)
                            {
                                idIngredient = Convert.ToInt32(result); 
                            }
                            else
                            {
                                string queryInsertIngredient = "INSERT INTO Ingrédient (nom_ingredient) VALUES (@NomIngredient)";
                                using (MySqlCommand cmdInsertIngredient = new MySqlCommand(queryInsertIngredient, conn))
                                {
                                    cmdInsertIngredient.Parameters.AddWithValue("@NomIngredient", nomIngredient);
                                    cmdInsertIngredient.ExecuteNonQuery();
                                }

                                using (MySqlCommand cmdLastId = new MySqlCommand("SELECT LAST_INSERT_ID()", conn))
                                {
                                    idIngredient = Convert.ToInt32(cmdLastId.ExecuteScalar());
                                }
                            }
                        }

                        string queryComposee = "INSERT INTO Composée (id_ingredient, id_recette) VALUES (@IdIngredient, @IdRecette)";
                        using (MySqlCommand cmdComposee = new MySqlCommand(queryComposee, conn))
                        {
                            cmdComposee.Parameters.AddWithValue("@IdIngredient", idIngredient);
                            cmdComposee.Parameters.AddWithValue("@IdRecette", idRecette);
                            cmdComposee.ExecuteNonQuery();
                        }
                    }

                    conn.Close();
                }

                MessageBox.Show("Plat ajouté avec succès !");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du plat : " + ex.Message);
            }
        }

        /// <summary>
        /// Événement déclenché lorsque l'utilisateur clique sur le bouton "Retour". 
        /// Ferme la fenêtre actuelle et ouvre la liste des plats du cuisinier.
        /// </summary>
        private void buttonRetour_Click(object sender, EventArgs e)
        {
            this.Hide();
            ListePlatsCuisinier loginForm = new ListePlatsCuisinier();
            loginForm.Show();
        }
    }
}
