﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace PInterface
{
    /// <summary>
    /// Formulaire d'inscription pour les clients.
    /// </summary>
    public partial class Inscription_Client : Form
    {
        /// <summary>
        /// Initialise une nouvelle instance de la classe Inscription_Client.
        /// </summary>
        public Inscription_Client()
        {
            InitializeComponent();
        }

        private string connectionString = "Server=localhost;Database=projetSQL;Uid=root;Pwd=root;";

        /// <summary>
        /// Gère l'événement de clic sur le bouton d'inscription.
        /// </summary>
        /// <param name="sender">La source de l'événement.</param>
        /// <param name="e">Les données de l'événement.</param>
        private void button1_Click(object sender, EventArgs e)
        {
            string prenom = textPrenom.Text.Trim();
            string nom = textNom.Text.Trim();
            string mdp = textMDP.Text.Trim();
            string email = textMail.Text.Trim();
            string telephone = textTelephone.Text.Trim();
            string rue = textRue.Text.Trim();
            string ville = textVille.Text.Trim();
            string codePostal = textCP.Text.Trim();
            string station = textStation.Text.Trim();
            string numero = textNum.Text.Trim();
            string prefAlimentaire = textPrefAlim.Text.Trim();
            string pseudoClient = textPseudoClient.Text.Trim(); 

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string queryIndividu = "INSERT INTO Individu (telephone, prenom, nom, email, Mot_de_passe) " +
                                           "VALUES (@Telephone, @Prenom, @Nom, @Email, @MDP)";

                    using (MySqlCommand cmdIndividu = new MySqlCommand(queryIndividu, conn))
                    {
                        cmdIndividu.Parameters.AddWithValue("@Telephone", telephone);
                        cmdIndividu.Parameters.AddWithValue("@Prenom", prenom);
                        cmdIndividu.Parameters.AddWithValue("@Nom", nom);
                        cmdIndividu.Parameters.AddWithValue("@Email", email);
                        cmdIndividu.Parameters.AddWithValue("@MDP", mdp);

                        int rowsAffected = cmdIndividu.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            string queryAdresse = "INSERT INTO Adresse ( rue, ville, code_postal, station_la_plus_proche, numero, telephone) " +
                                                  "VALUES ( @Rue, @Ville, @CodePostal, @Station, @Numero, @Telephone)";

                            using (MySqlCommand cmdAdresse = new MySqlCommand(queryAdresse, conn))
                            {
                                cmdAdresse.Parameters.AddWithValue("@Rue", rue);
                                cmdAdresse.Parameters.AddWithValue("@Ville", ville);
                                cmdAdresse.Parameters.AddWithValue("@CodePostal", codePostal);
                                cmdAdresse.Parameters.AddWithValue("@Station", station);
                                cmdAdresse.Parameters.AddWithValue("@Numero", numero);
                                cmdAdresse.Parameters.AddWithValue("@Telephone", telephone);

                                int rowsAffectedAdresse = cmdAdresse.ExecuteNonQuery();

                                if (rowsAffectedAdresse > 0)
                                {
                                    string queryClient = "INSERT INTO Client_Individuel (pseudo_client, pref_alimentaire, telephone) " +
                                                         "VALUES (@PseudoClient, @PrefAlimentaire, @Telephone)";

                                    using (MySqlCommand cmdClient = new MySqlCommand(queryClient, conn))
                                    {
                                        cmdClient.Parameters.AddWithValue("@PseudoClient", pseudoClient);
                                        cmdClient.Parameters.AddWithValue("@PrefAlimentaire", prefAlimentaire);
                                        cmdClient.Parameters.AddWithValue("@Telephone", telephone);

                                        int rowsAffectedClient = cmdClient.ExecuteNonQuery();

                                        if (rowsAffectedClient > 0)
                                        {
                                            MessageBox.Show("Inscription réussie !", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                            this.Hide();
                                            Connexion_Client loginForm = new Connexion_Client();
                                            loginForm.Show();
                                        }
                                        else
                                        {
                                            MessageBox.Show("Échec de l'inscription du client.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Échec de l'inscription de l'adresse.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Échec de l'inscription.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'inscription : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Gère l'événement de chargement du formulaire.
        /// </summary>
        /// <param name="sender">La source de l'événement.</param>
        /// <param name="e">Les données de l'événement.</param>
        private void Inscription_Client_Load(object sender, EventArgs e)
        {
            // Code pour le chargement du formulaire
        }

        /// <summary>
        /// Gère l'événement de clic sur le bouton pour revenir à la connexion.
        /// </summary>
        /// <param name="sender">La source de l'événement.</param>
        /// <param name="e">Les données de l'événement.</param>
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connexion_Client loginForm = new Connexion_Client();
            loginForm.Show();
        }
    }
}
