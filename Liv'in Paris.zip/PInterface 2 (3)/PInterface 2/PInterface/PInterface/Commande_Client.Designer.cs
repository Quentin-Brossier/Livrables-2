﻿namespace PInterface
{
    partial class Commande_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewPlats = new DataGridView();
            button1 = new Button();
            buttonAjouterPanier = new Button();
            buttonEnleverPanier = new Button();
            dataGridViewPanier = new DataGridView();
            labelPrixTotal = new Label();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlats).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPanier).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewPlats
            // 
            dataGridViewPlats.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPlats.Location = new Point(29, 53);
            dataGridViewPlats.Name = "dataGridViewPlats";
            dataGridViewPlats.RowHeadersWidth = 51;
            dataGridViewPlats.Size = new Size(721, 417);
            dataGridViewPlats.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(1020, 505);
            button1.Name = "button1";
            button1.Size = new Size(115, 29);
            button1.TabIndex = 2;
            button1.Text = "Commander";
            button1.UseVisualStyleBackColor = true;
            button1.Click += buttonCommander_Click;
            // 
            // buttonAjouterPanier
            // 
            buttonAjouterPanier.Location = new Point(166, 505);
            buttonAjouterPanier.Name = "buttonAjouterPanier";
            buttonAjouterPanier.Size = new Size(160, 29);
            buttonAjouterPanier.TabIndex = 3;
            buttonAjouterPanier.Text = "Mettre au panier";
            buttonAjouterPanier.UseVisualStyleBackColor = true;
            buttonAjouterPanier.Click += buttonAjouterPanier_Click_1;
            // 
            // buttonEnleverPanier
            // 
            buttonEnleverPanier.Location = new Point(453, 505);
            buttonEnleverPanier.Name = "buttonEnleverPanier";
            buttonEnleverPanier.Size = new Size(159, 29);
            buttonEnleverPanier.TabIndex = 4;
            buttonEnleverPanier.Text = "Enlever du panier";
            buttonEnleverPanier.UseVisualStyleBackColor = true;
            buttonEnleverPanier.Click += buttonEnleverPanier_Click_1;
            // 
            // dataGridViewPanier
            // 
            dataGridViewPanier.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPanier.Location = new Point(839, 53);
            dataGridViewPanier.Name = "dataGridViewPanier";
            dataGridViewPanier.RowHeadersWidth = 51;
            dataGridViewPanier.Size = new Size(442, 417);
            dataGridViewPanier.TabIndex = 5;
            // 
            // labelPrixTotal
            // 
            labelPrixTotal.AutoSize = true;
            labelPrixTotal.BackColor = SystemColors.Control;
            labelPrixTotal.Location = new Point(839, 473);
            labelPrixTotal.Name = "labelPrixTotal";
            labelPrixTotal.Size = new Size(33, 20);
            labelPrixTotal.TabIndex = 6;
            labelPrixTotal.Text = "Prix";
            // 
            // button2
            // 
            button2.Location = new Point(29, 12);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 7;
            button2.Text = "Retour";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Commande_Client
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1352, 571);
            Controls.Add(button2);
            Controls.Add(labelPrixTotal);
            Controls.Add(dataGridViewPanier);
            Controls.Add(buttonEnleverPanier);
            Controls.Add(buttonAjouterPanier);
            Controls.Add(button1);
            Controls.Add(dataGridViewPlats);
            Name = "Commande_Client";
            Text = "Commande_Client";
            Load += Commande_Client_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlats).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPanier).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dataGridViewPlats;
        private Button button1;
        private Button buttonAjouterPanier;
        private Button buttonEnleverPanier;
        private DataGridView dataGridViewPanier;
        private Label labelPrixTotal;
        private Button button2;
    }
}