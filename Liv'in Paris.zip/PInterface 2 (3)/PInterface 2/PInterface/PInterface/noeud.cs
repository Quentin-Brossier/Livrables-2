﻿using System.Drawing;

namespace projet
{
    /// <summary>
    /// Représente un nœud dans un graphe, associé à une station et une position.
    /// </summary>
    public class Noeud
    {
        /// <summary>
        /// Obtient la station associée au nœud.
        /// </summary>
        public Station Station { get; }

        /// <summary>
        /// Obtient la position du nœud dans le graphe.
        /// </summary>
        public PointF Position { get; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe Noeud.
        /// </summary>
        /// <param name="station">La station associée au nœud.</param>
        /// <param name="position">La position du nœud dans le graphe.</param>
        public Noeud(Station station, PointF position)
        {
            this.Station = station;
            this.Position = position;
        }
    }
}
    