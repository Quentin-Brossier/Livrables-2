using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PInterface
{
    /// <summary>
    /// Formulaire d'inscription pour les cuisiniers.
    /// </summary>
    public partial class Inscription_Cuisinier : Form
    {
        /// <summary>
        /// Initialise une nouvelle instance de la classe Inscription_Cuisinier.
        /// </summary>
        public Inscription_Cuisinier()
        {
            InitializeComponent();
        }

        private string connectionString = "Server=localhost;Database=projetSQL;Uid=root;Pwd=root;";

        /// <summary>
        /// G�re l'�v�nement de clic sur le bouton d'inscription.
        /// </summary>
        /// <param name="sender">La source de l'�v�nement.</param>
        /// <param name="e">Les donn�es de l'�v�nement.</param>
        private void button1_Click(object sender, EventArgs e)
        {
            string prenom = textPrenom.Text.Trim();
            string nom = textNom.Text.Trim();
            string mdp = textMDP.Text.Trim();
            string email = textMail.Text.Trim();
            string telephone = textTelephone.Text.Trim();
            string rue = textRue.Text.Trim();
            string ville = textVille.Text.Trim();
            string codePostal = textCP.Text.Trim();
            string station = textStation.Text.Trim();
            string numero = textNum.Text.Trim();
            string speCuisine = textSpecialite.Text.Trim();
            string anneeExp = textEXP.Text.Trim();
            string pseudoCuisinier = textPseudo.Text.Trim();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string queryIndividu = "INSERT INTO Individu (telephone, prenom, nom, email, Mot_de_passe) " +
                                           "VALUES (@Telephone, @Prenom, @Nom, @Email, @MDP)";

                    using (MySqlCommand cmdIndividu = new MySqlCommand(queryIndividu, conn))
                    {
                        cmdIndividu.Parameters.AddWithValue("@Telephone", telephone);
                        cmdIndividu.Parameters.AddWithValue("@Prenom", prenom);
                        cmdIndividu.Parameters.AddWithValue("@Nom", nom);
                        cmdIndividu.Parameters.AddWithValue("@Email", email);
                        cmdIndividu.Parameters.AddWithValue("@MDP", mdp); 

                        int rowsAffected = cmdIndividu.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            string queryAdresse = "INSERT INTO Adresse ( rue, ville, code_postal, station_la_plus_proche, numero, telephone) " +
                                                  "VALUES ( @Rue, @Ville, @CodePostal, @Station, @Numero, @Telephone)";

                            using (MySqlCommand cmdAdresse = new MySqlCommand(queryAdresse, conn))
                            {
                                cmdAdresse.Parameters.AddWithValue("@Rue", rue);
                                cmdAdresse.Parameters.AddWithValue("@Ville", ville);
                                cmdAdresse.Parameters.AddWithValue("@CodePostal", codePostal);
                                cmdAdresse.Parameters.AddWithValue("@Station", station);
                                cmdAdresse.Parameters.AddWithValue("@Numero", numero);
                                cmdAdresse.Parameters.AddWithValue("@Telephone", telephone);

                                int rowsAffectedAdresse = cmdAdresse.ExecuteNonQuery();

                                if (rowsAffectedAdresse > 0)
                                {
                                    string queryCuisinier = "INSERT INTO Cuisinier (pseudo_cuisinier, spe_cuisine, annee_exp, telephone) " +
                                                           "VALUES (@PseudoCuisinier, @SpeCuisine, @AnneeExp, @Telephone)";

                                    using (MySqlCommand cmdCuisinier = new MySqlCommand(queryCuisinier, conn))
                                    {
                                        cmdCuisinier.Parameters.AddWithValue("@PseudoCuisinier", pseudoCuisinier);
                                        cmdCuisinier.Parameters.AddWithValue("@SpeCuisine", speCuisine);
                                        cmdCuisinier.Parameters.AddWithValue("@AnneeExp", anneeExp);
                                        cmdCuisinier.Parameters.AddWithValue("@Telephone", telephone);

                                        int rowsAffectedCuisinier = cmdCuisinier.ExecuteNonQuery();

                                        if (rowsAffectedCuisinier > 0)
                                        {
                                            MessageBox.Show("Inscription r�ussie !", "Succ�s", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                            this.Hide();
                                            Connexion_Cuisinier loginForm = new Connexion_Cuisinier();
                                            loginForm.Show();
                                        }
                                        else
                                        {
                                            MessageBox.Show("�chec de l'inscription du cuisinier.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("�chec de l'inscription de l'adresse.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("�chec de l'inscription.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'inscription : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// G�re l'�v�nement de clic sur le bouton pour revenir � la connexion.
        /// </summary>
        /// <param name="sender">La source de l'�v�nement.</param>
        /// <param name="e">Les donn�es de l'�v�nement.</param>
        private void button2_Click_(object sender, EventArgs e)
        {
            this.Hide();
            Connexion_Cuisinier loginForm = new Connexion_Cuisinier();
            loginForm.Show();
        }

        /// <summary>
        /// G�re l'�v�nement de chargement du formulaire.
        /// </summary>
        /// <param name="sender">La source de l'�v�nement.</param>
        /// <param name="e">Les donn�es de l'�v�nement.</param>
        private void Inscription_Cuisinier_Load(object sender, EventArgs e)
        {
            // Code pour le chargement du formulaire
        }
    }
}
