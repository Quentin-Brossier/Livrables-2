﻿namespace PInterface
{
    partial class Inscription_Cuisinier
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textNom = new TextBox();
            textPrenom = new TextBox();
            textMDP = new TextBox();
            textMail = new TextBox();
            textTelephone = new TextBox();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            textRue = new TextBox();
            textVille = new TextBox();
            textCP = new TextBox();
            textNum = new TextBox();
            textStation = new TextBox();
            label11 = new Label();
            label12 = new Label();
            textSpecialite = new TextBox();
            textEXP = new TextBox();
            label13 = new Label();
            textPseudo = new TextBox();
            label14 = new Label();
            button2 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(512, 340);
            button1.Name = "button1";
            button1.Size = new Size(150, 50);
            button1.TabIndex = 0;
            button1.Text = "Inscription";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(41, 111);
            label1.Name = "label1";
            label1.Size = new Size(42, 20);
            label1.TabIndex = 1;
            label1.Text = "Nom";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(41, 140);
            label2.Name = "label2";
            label2.Size = new Size(60, 20);
            label2.TabIndex = 2;
            label2.Text = "Prénom";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(41, 209);
            label3.Name = "label3";
            label3.Size = new Size(38, 20);
            label3.TabIndex = 3;
            label3.Text = "Mail";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(41, 176);
            label4.Name = "label4";
            label4.Size = new Size(98, 20);
            label4.TabIndex = 4;
            label4.Text = "Mot de passe";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(41, 250);
            label5.Name = "label5";
            label5.Size = new Size(78, 20);
            label5.TabIndex = 5;
            label5.Text = "Téléphone";
            // 
            // textNom
            // 
            textNom.Location = new Point(167, 108);
            textNom.Name = "textNom";
            textNom.Size = new Size(125, 27);
            textNom.TabIndex = 6;
            // 
            // textPrenom
            // 
            textPrenom.Location = new Point(167, 141);
            textPrenom.Name = "textPrenom";
            textPrenom.Size = new Size(125, 27);
            textPrenom.TabIndex = 7;
            // 
            // textMDP
            // 
            textMDP.Location = new Point(167, 176);
            textMDP.Name = "textMDP";
            textMDP.Size = new Size(125, 27);
            textMDP.TabIndex = 8;
            // 
            // textMail
            // 
            textMail.Location = new Point(167, 209);
            textMail.Name = "textMail";
            textMail.Size = new Size(125, 27);
            textMail.TabIndex = 9;
            // 
            // textTelephone
            // 
            textTelephone.Location = new Point(167, 247);
            textTelephone.Name = "textTelephone";
            textTelephone.Size = new Size(125, 27);
            textTelephone.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(537, 114);
            label6.Name = "label6";
            label6.Size = new Size(34, 20);
            label6.TabIndex = 11;
            label6.Text = "Rue";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(537, 147);
            label7.Name = "label7";
            label7.Size = new Size(38, 20);
            label7.TabIndex = 12;
            label7.Text = "Ville";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(486, 182);
            label8.Name = "label8";
            label8.Size = new Size(89, 20);
            label8.TabIndex = 13;
            label8.Text = "Code postal";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(512, 215);
            label9.Name = "label9";
            label9.Size = new Size(63, 20);
            label9.TabIndex = 14;
            label9.Text = "Numéro";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(333, 257);
            label10.Name = "label10";
            label10.Size = new Size(242, 20);
            label10.TabIndex = 15;
            label10.Text = "Station la plus proche de chez vous";
            // 
            // textRue
            // 
            textRue.Location = new Point(595, 111);
            textRue.Name = "textRue";
            textRue.Size = new Size(125, 27);
            textRue.TabIndex = 16;
            // 
            // textVille
            // 
            textVille.Location = new Point(595, 147);
            textVille.Name = "textVille";
            textVille.Size = new Size(125, 27);
            textVille.TabIndex = 17;
            // 
            // textCP
            // 
            textCP.Location = new Point(595, 179);
            textCP.Name = "textCP";
            textCP.Size = new Size(125, 27);
            textCP.TabIndex = 18;
            // 
            // textNum
            // 
            textNum.Location = new Point(595, 215);
            textNum.Name = "textNum";
            textNum.Size = new Size(125, 27);
            textNum.TabIndex = 19;
            // 
            // textStation
            // 
            textStation.Location = new Point(595, 253);
            textStation.Name = "textStation";
            textStation.Size = new Size(125, 27);
            textStation.TabIndex = 20;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(840, 111);
            label11.Name = "label11";
            label11.Size = new Size(134, 20);
            label11.TabIndex = 21;
            label11.Text = "Spécialité culinaire";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(840, 144);
            label12.Name = "label12";
            label12.Size = new Size(139, 20);
            label12.TabIndex = 22;
            label12.Text = "Année d'expérience";
            // 
            // textSpecialite
            // 
            textSpecialite.Location = new Point(980, 107);
            textSpecialite.Name = "textSpecialite";
            textSpecialite.Size = new Size(125, 27);
            textSpecialite.TabIndex = 23;
            // 
            // textEXP
            // 
            textEXP.Location = new Point(980, 144);
            textEXP.Name = "textEXP";
            textEXP.Size = new Size(125, 27);
            textEXP.TabIndex = 24;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(917, 186);
            label13.Name = "label13";
            label13.Size = new Size(57, 20);
            label13.TabIndex = 25;
            label13.Text = "Pseudo";
            // 
            // textPseudo
            // 
            textPseudo.Location = new Point(980, 179);
            textPseudo.Name = "textPseudo";
            textPseudo.Size = new Size(125, 27);
            textPseudo.TabIndex = 26;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(535, 14);
            label14.Name = "label14";
            label14.Size = new Size(76, 20);
            label14.TabIndex = 27;
            label14.Text = "Liv'in Paris";
            // 
            // button2
            // 
            button2.Location = new Point(12, 12);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 28;
            button2.Text = "Retour";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_;
            // 
            // Inscription_Cuisinier
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1126, 450);
            Controls.Add(button2);
            Controls.Add(label14);
            Controls.Add(textPseudo);
            Controls.Add(label13);
            Controls.Add(textEXP);
            Controls.Add(textSpecialite);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(textStation);
            Controls.Add(textNum);
            Controls.Add(textCP);
            Controls.Add(textVille);
            Controls.Add(textRue);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(textTelephone);
            Controls.Add(textMail);
            Controls.Add(textMDP);
            Controls.Add(textPrenom);
            Controls.Add(textNom);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Inscription_Cuisinier";
            Text = "Form1";
            Load += Inscription_Cuisinier_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textNom;
        private TextBox textPrenom;
        private TextBox textMDP;
        private TextBox textMail;
        private TextBox textTelephone;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private TextBox textRue;
        private TextBox textVille;
        private TextBox textCP;
        private TextBox textNum;
        private TextBox textStation;
        private Label label11;
        private Label label12;
        private TextBox textSpecialite;
        private TextBox textEXP;
        private Label label13;
        private TextBox textPseudo;
        private Label label14;
        private Button button2;
    }
}
