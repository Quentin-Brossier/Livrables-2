using PInterface;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace projet
{
    public partial class Form1 : Form
    {
        [DllImport("kernel32.dll")]
        static extern bool AllocConsole();

        private Graphe _graphe = new Graphe();
        private VisualiseurGraphe _visualiseurGraphe;
        private float _zoom = 0.28f;
        private PointF _translation = new PointF(700, 500);
        private ComboBox _comboBoxStationDepart;
        private ComboBox _comboBoxStationArrivee;
        private ComboBox _comboBoxStationFermee;
        private Button _boutonDijkstra;
        private Button _boutonBellmanFord;
        private Button _boutonFermerStation;
        private Label _labelChemin;
        private List<Noeud> _cheminNoeuds = new List<Noeud>();
        private List<Tuple<PointF, PointF>> _cheminLignes = new List<Tuple<PointF, PointF>>();
        private string _nomStationFermee = null;

        public Form1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            _graphe.ChargerStationsDepuisCSV("MetroParis.csv");
            _graphe.ChargerLignesDepuisCSV("MetroParis_Lignes.csv");

            _visualiseurGraphe = new VisualiseurGraphe(_graphe, _zoom, _translation);

            _comboBoxStationDepart = new ComboBox { Width = 200, DropDownStyle = ComboBoxStyle.DropDown };
            _comboBoxStationDepart.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            _comboBoxStationDepart.AutoCompleteSource = AutoCompleteSource.ListItems;

            _comboBoxStationArrivee = new ComboBox { Width = 200, DropDownStyle = ComboBoxStyle.DropDown };
            _comboBoxStationArrivee.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            _comboBoxStationArrivee.AutoCompleteSource = AutoCompleteSource.ListItems;

            _comboBoxStationFermee = new ComboBox { Width = 200, DropDownStyle = ComboBoxStyle.DropDown };
            _comboBoxStationFermee.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            _comboBoxStationFermee.AutoCompleteSource = AutoCompleteSource.ListItems;

            _boutonDijkstra = new Button { Text = "Dijkstra" };
            _boutonBellmanFord = new Button { Text = "Bellman-Ford" };
            _boutonFermerStation = new Button { Text = "Fermer Station" };
            var boutonReset = new Button { Text = "Reset" };
            _labelChemin = new Label { AutoSize = true, MaximumSize = new Size(800, 0) };

            _boutonDijkstra.Click += (sender, e) => UtiliserDijkstra();
            _boutonBellmanFord.Click += (sender, e) => UtiliserBellmanFord();
            _boutonFermerStation.Click += (sender, e) => FermerStation();
            boutonReset.Click += (sender, e) => ResetAffichage();

            var panel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 50 };
            panel.Controls.Add(_comboBoxStationDepart);
            panel.Controls.Add(_comboBoxStationArrivee);
            panel.Controls.Add(_boutonDijkstra);
            panel.Controls.Add(_boutonBellmanFord);
            panel.Controls.Add(boutonReset);
            this.Controls.Add(panel);

            var fermerPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 50 };
            fermerPanel.Controls.Add(_comboBoxStationFermee);
            fermerPanel.Controls.Add(_boutonFermerStation);
            this.Controls.Add(fermerPanel);

            var labelPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 50 };
            labelPanel.Controls.Add(_labelChemin);
            this.Controls.Add(labelPanel);

            RemplirComboBoxStations();
        }

        private void RemplirComboBoxStations()
        {
            var nomsStations = _graphe.Noeuds.Select(n => n.Station.Nom).ToList();
            _comboBoxStationDepart.Items.AddRange(nomsStations.ToArray());
            _comboBoxStationArrivee.Items.AddRange(nomsStations.ToArray());
            _comboBoxStationFermee.Items.AddRange(nomsStations.ToArray());
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            try
            {
                _visualiseurGraphe.Dessiner(e.Graphics);

                if (_cheminNoeuds.Count > 0 && _cheminLignes.Count > 0)
                {
                    foreach (var ligne in _cheminLignes)
                    {
                        Pen pen = new Pen(Color.Red, 45);
                        e.Graphics.DrawLine(pen, ligne.Item1, ligne.Item2);
                    }

                    foreach (var noeud in _cheminNoeuds)
                    {
                        Brush couleurNoeud = new SolidBrush(Color.Red);
                        float tailleCercle = 80;
                        e.Graphics.FillEllipse(couleurNoeud, noeud.Position.X - tailleCercle / 2, noeud.Position.Y - tailleCercle / 2, tailleCercle, tailleCercle);
                        e.Graphics.DrawEllipse(Pens.Black, noeud.Position.X - tailleCercle / 2, noeud.Position.Y - tailleCercle / 2, tailleCercle, tailleCercle);

                        string texte = noeud.Station.Nom;
                        Font font = new Font("Arial", 8, FontStyle.Bold);
                        SizeF tailleTexte = e.Graphics.MeasureString(texte, font);
                        float texteX = noeud.Position.X - tailleTexte.Width / 2;
                        float texteY = noeud.Position.Y - tailleTexte.Height / 2;
                        e.Graphics.DrawString(texte, font, Brushes.Black, texteX, texteY);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du dessin : {ex.Message}");
            }
        }

        private void UtiliserDijkstra()
        {
            try
            {
                _graphe.Dijkstra(_comboBoxStationDepart.Text, _comboBoxStationArrivee.Text, _nomStationFermee, out _cheminNoeuds, out _cheminLignes);
                AfficherChemin();
                this.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UtiliserBellmanFord()
        {
            try
            {
                _graphe.BellmanFord(_comboBoxStationDepart.Text, _comboBoxStationArrivee.Text, _nomStationFermee, out _cheminNoeuds, out _cheminLignes);
                AfficherChemin();
                this.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FermerConnexionsStation(string nomStation)
        {
            var station = _graphe.Noeuds.FirstOrDefault(n => n.Station.Nom == nomStation)?.Station;
            if (station == null) return;

            foreach (var ligne in station.Lignes)
            {
                var stationSuivante = _graphe.Noeuds.FirstOrDefault(n => n.Station.Nom == ligne)?.Station;
                if (stationSuivante != null)
                {
                    stationSuivante.Lignes.Remove(nomStation);
                }
            }
            station.Lignes.Clear();
        }

        private void FermerStation()
        {
            _nomStationFermee = _comboBoxStationFermee.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(_nomStationFermee))
            {
                FermerConnexionsStation(_nomStationFermee);
            }
        }

        private void ReouvrirConnexionsStation(string nomStation)
        {
            var station = _graphe.Noeuds.FirstOrDefault(n => n.Station.Nom == nomStation)?.Station;
            if (station == null) return;

            // Recharger les lignes depuis le fichier CSV pour restaurer les connexions
            _graphe.ChargerLignesDepuisCSV("MetroParis_Lignes.csv");
        }

        private void ResetAffichage()
        {
            _cheminNoeuds.Clear();
            _cheminLignes.Clear();
            _labelChemin.Text = string.Empty;

            if (!string.IsNullOrEmpty(_nomStationFermee))
            {
                ReouvrirConnexionsStation(_nomStationFermee);
                _nomStationFermee = null;
            }

            this.Invalidate();
        }

        private void AfficherChemin()
        {
            if (_cheminNoeuds.Count == 0)
            {
                _labelChemin.Text = "Aucun chemin trouv�.";
                return;
            }

            var sb = new StringBuilder();
            sb.Append($"D�part: {_cheminNoeuds.First().Station.Nom} Ligne: {_cheminNoeuds.First().Station.Ligne}");
            for (int i = 1; i < _cheminNoeuds.Count; i++)
            {
                var noeud = _cheminNoeuds[i];
                var prevNoeud = _cheminNoeuds[i - 1];
                if (noeud.Station.Ligne != prevNoeud.Station.Ligne)
                {
                    sb.Append($" -> {prevNoeud.Station.Nom} Ligne: {noeud.Station.Ligne}");
                }
            }
            sb.Append($" -> Arriv�e: {_cheminNoeuds.Last().Station.Nom} Ligne: {_cheminNoeuds.Last().Station.Ligne}");

            _labelChemin.Text = sb.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Graphe_Plat loginForm = new Graphe_Plat();
            loginForm.Show();

        }
    }
}
