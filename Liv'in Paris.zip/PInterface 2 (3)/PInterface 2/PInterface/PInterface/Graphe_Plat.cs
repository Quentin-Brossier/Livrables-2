﻿using projet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PInterface
{
    public partial class Graphe_Plat : Form
    {
        public Graphe_Plat()
        {
            InitializeComponent();
        }
        private string pseudoCuisinier;




        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            ListePlatsCuisinier loginForm = new ListePlatsCuisinier();
            loginForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        private void buttonRetour_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connexion_Cuisinier loginForm = new Connexion_Cuisinier();
            loginForm.Show();
        }

        private void Graphe_Plat_Load(object sender, EventArgs e)
        {

        }
    }
}
