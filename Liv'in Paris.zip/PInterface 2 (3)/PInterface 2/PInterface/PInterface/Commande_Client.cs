﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PInterface
{
    public partial class Commande_Client : Form
    {
        private string pseudoClient;
        private string connectionString = "Server=localhost;Database=projetSQL;Uid=root;Pwd=root;";
        private List<string> panier = new List<string>();

        /// <summary>
        /// Constructeur de la classe Commande_Client. 
        /// Initialise le formulaire et charge les plats disponibles.
        /// </summary>
        public Commande_Client(string pseudo)
        {
            InitializeComponent();
            ConfigurerDataGridView();
            ChargerPlats();
            pseudoClient = pseudo;
        }

        /// <summary>
        /// Configure les DataGridViews pour afficher les plats et le panier.
        /// </summary>
        private void ConfigurerDataGridView()
        {
            dataGridViewPlats.Columns.Clear();
            dataGridViewPlats.Columns.Add("nom_plat", "Nom du Plat");
            dataGridViewPlats.Columns.Add("prix", "Prix (€)");
            dataGridViewPlats.Columns.Add("regime", "Régime");
            dataGridViewPlats.Columns.Add("ingredients", "Ingrédients");
            dataGridViewPlats.Columns.Add("quantite", "Quantité (g)");

            dataGridViewPlats.ReadOnly = true;
            dataGridViewPlats.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewPlats.MultiSelect = true;

            dataGridViewPlats.Columns["nom_plat"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewPlats.Columns["prix"].Width = 80;
            dataGridViewPlats.Columns["regime"].Width = 120;
            dataGridViewPlats.Columns["ingredients"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewPlats.Columns["quantite"].Width = 100;

            dataGridViewPanier.Columns.Clear();
            dataGridViewPanier.Columns.Add("nom_plat_panier", "Nom du Plat");
            dataGridViewPanier.Columns.Add("prix_panier", "Prix (€)");

            dataGridViewPanier.ReadOnly = true;
            dataGridViewPanier.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewPanier.MultiSelect = true;

            dataGridViewPanier.Columns["nom_plat_panier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewPanier.Columns["prix_panier"].Width = 80;

            labelPrixTotal.Text = "Prix Total : 0€";
        }

        /// <summary>
        /// Charge les plats depuis la base de données et les affiche dans le DataGridView.
        /// </summary>
        private void ChargerPlats()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
                    SELECT 
                        P.nom_plat, 
                        P.prix, 
                        R.regime_alimentaire, 
                        GROUP_CONCAT(I.nom_ingredient SEPARATOR ', ') AS ingredients, 
                        P.quantite 
                    FROM Plat P
                    LEFT JOIN recette R ON P.id_recette = R.id_recette
                    LEFT JOIN composée C ON R.id_recette = C.id_recette
                    LEFT JOIN Ingrédient I ON C.id_ingredient = I.id_ingredient
                    GROUP BY P.id_plat, P.nom_plat, P.prix, R.regime_alimentaire, P.quantite";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            dataGridViewPlats.Rows.Clear();
                            while (reader.Read())
                            {
                                string nomPlat = reader.GetString("nom_plat");
                                decimal prix = reader.GetDecimal("prix");
                                string regime = reader.IsDBNull(reader.GetOrdinal("regime_alimentaire")) ? "Non spécifié" : reader.GetString("regime_alimentaire");
                                string ingredients = reader.IsDBNull(reader.GetOrdinal("ingredients")) || string.IsNullOrEmpty(reader.GetString("ingredients"))
                                    ? "Aucun ingrédient"
                                    : reader.GetString("ingredients");
                                int quantite = reader.IsDBNull(reader.GetOrdinal("quantite")) ? 0 : reader.GetInt32("quantite");

                                dataGridViewPlats.Rows.Add(nomPlat, prix, regime, ingredients, quantite);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des plats : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Événement déclenché lorsqu'un plat est ajouté au panier.
        /// </summary>
        private void buttonAjouterPanier_Click_1(object sender, EventArgs e)
        {
            if (dataGridViewPlats.SelectedRows.Count == 0)
            {
                MessageBox.Show("Veuillez sélectionner un plat à ajouter au panier.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (DataGridViewRow row in dataGridViewPlats.SelectedRows)
            {
                string nomPlat = row.Cells["nom_plat"].Value.ToString();

                if (!panier.Contains(nomPlat))
                {
                    panier.Add(nomPlat);
                }
            }

            MettreAJourPanier();
        }

        /// <summary>
        /// Événement déclenché lorsqu'un plat est retiré du panier.
        /// </summary>
        private void buttonEnleverPanier_Click_1(object sender, EventArgs e)
        {
            if (dataGridViewPanier.SelectedRows.Count == 0)
            {
                MessageBox.Show("Veuillez sélectionner un plat à enlever du panier.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (DataGridViewRow row in dataGridViewPanier.SelectedRows)
            {
                string nomPlat = row.Cells["nom_plat_panier"].Value.ToString();

                if (panier.Contains(nomPlat))
                {
                    panier.Remove(nomPlat);
                }
            }

            MettreAJourPanier();
        }

        /// <summary>
        /// Événement déclenché lors de la validation de la commande.
        /// Enregistre la commande et les plats dans la base de données.
        /// </summary>
        private void buttonCommander_Click(object sender, EventArgs e)
        {
            if (panier.Count == 0)
            {
                MessageBox.Show("Votre panier est vide, veuillez ajouter des plats avant de valider.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string queryCommande = "INSERT INTO Commande (date_commande, pseudo_client) VALUES (NOW(), @PseudoClient)";
                    int idCommande;

                    using (MySqlCommand cmdCommande = new MySqlCommand(queryCommande, conn))
                    {
                        cmdCommande.Parameters.AddWithValue("@PseudoClient", pseudoClient);
                        cmdCommande.ExecuteNonQuery();
                        idCommande = (int)cmdCommande.LastInsertedId;
                    }

                    foreach (var nomPlat in panier)
                    {
                        string queryPlatCommande = "INSERT INTO Contient (id_commande, id_plat) " +
                                                   "SELECT @IdCommande, id_plat FROM Plat WHERE nom_plat = @NomPlat";

                        using (MySqlCommand cmdPlatCommande = new MySqlCommand(queryPlatCommande, conn))
                        {
                            cmdPlatCommande.Parameters.AddWithValue("@IdCommande", idCommande);
                            cmdPlatCommande.Parameters.AddWithValue("@NomPlat", nomPlat);
                            cmdPlatCommande.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Commande passée avec succès !", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    panier.Clear();
                    MettreAJourPanier();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du passage de commande : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Met à jour l'affichage du panier et le prix total.
        /// </summary>
        private void MettreAJourPanier()
        {
            dataGridViewPanier.Rows.Clear();

            decimal total = 0;

            foreach (var plat in panier)
            {
                string nomPlat = plat;
                decimal prix = GetPrixPlat(nomPlat);

                dataGridViewPanier.Rows.Add(nomPlat, prix);

                total += prix;
            }

            labelPrixTotal.Text = $"Prix Total : {total}€";
        }

        /// <summary>
        /// Récupère le prix d'un plat depuis la base de données.
        /// </summary>
        private decimal GetPrixPlat(string nomPlat)
        {
            decimal prix = 0;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT prix FROM Plat WHERE nom_plat = @NomPlat";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@NomPlat", nomPlat);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                prix = reader.GetDecimal("prix");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la récupération du prix du plat : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return prix;
        }

        private void Commande_Client_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connexion_Client loginForm = new Connexion_Client();
            loginForm.Show();
        }
    }
}
