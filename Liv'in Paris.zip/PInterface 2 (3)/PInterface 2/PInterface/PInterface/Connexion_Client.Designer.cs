﻿namespace PInterface
{
    partial class Connexion_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button3 = new Button();
            label4 = new Label();
            textMDPCl = new TextBox();
            textPseudoCl = new TextBox();
            button1 = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(318, 314);
            button2.Name = "button2";
            button2.Size = new Size(150, 50);
            button2.TabIndex = 18;
            button2.Text = "Inscription";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(17, 22);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 17;
            button3.Text = "Retour";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(249, 274);
            label4.Name = "label4";
            label4.Size = new Size(316, 20);
            label4.TabIndex = 16;
            label4.Text = "Si vous n'avez pas de compte inscrivez vous ici";
            // 
            // textMDPCl
            // 
            textMDPCl.Location = new Point(333, 127);
            textMDPCl.Name = "textMDPCl";
            textMDPCl.Size = new Size(125, 27);
            textMDPCl.TabIndex = 15;
            // 
            // textPseudoCl
            // 
            textPseudoCl.Location = new Point(333, 87);
            textPseudoCl.Name = "textPseudoCl";
            textPseudoCl.Size = new Size(125, 27);
            textPseudoCl.TabIndex = 14;
            // 
            // button1
            // 
            button1.Location = new Point(318, 180);
            button1.Name = "button1";
            button1.Size = new Size(150, 50);
            button1.TabIndex = 13;
            button1.Text = "Connexion";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(208, 130);
            label3.Name = "label3";
            label3.Size = new Size(98, 20);
            label3.TabIndex = 12;
            label3.Text = "Mot de passe";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(249, 94);
            label2.Name = "label2";
            label2.Size = new Size(57, 20);
            label2.TabIndex = 11;
            label2.Text = "Pseudo";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(352, 9);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 10;
            label1.Text = "Liv'in Paris";
            // 
            // Connexion_Client
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(label4);
            Controls.Add(textMDPCl);
            Controls.Add(textPseudoCl);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Connexion_Client";
            Text = "Connexion_Client";
            Load += Connexion_Client_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button3;
        private Label label4;
        private TextBox textMDPCl;
        private TextBox textPseudoCl;
        private Button button1;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}