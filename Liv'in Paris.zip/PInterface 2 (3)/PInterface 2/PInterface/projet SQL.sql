CREATE DATABASE  IF NOT EXISTS `projetsql` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `projetsql`;
-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: projetsql
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adresse` (
  `id_adresse` int NOT NULL AUTO_INCREMENT,
  `rue` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `code_postal` varchar(10) NOT NULL,
  `station_la_plus_proche` varchar(50) DEFAULT NULL,
  `numero` int NOT NULL,
  `telephone` varchar(14) NOT NULL,
  PRIMARY KEY (`id_adresse`),
  KEY `telephone` (`telephone`),
  CONSTRAINT `adresse_ibfk_1` FOREIGN KEY (`telephone`) REFERENCES `individu` (`telephone`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adresse`
--

LOCK TABLES `adresse` WRITE;
/*!40000 ALTER TABLE `adresse` DISABLE KEYS */;
INSERT INTO `adresse` VALUES (1,'123 rue de Paris','Paris','75001','Châtelet',1,'0601020304'),(2,'456 avenue des Champs','Paris','75008','Opéra',2,'0612345678'),(3,'789 boulevard Saint-Germain','Paris','75005','Saint-Michel',3,'0698765432');
/*!40000 ALTER TABLE `adresse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avis_post_commande`
--

DROP TABLE IF EXISTS `avis_post_commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avis_post_commande` (
  `pseudo_client` varchar(50) NOT NULL,
  `pseudo_cuisinier` varchar(50) NOT NULL,
  `nb_etoile` int DEFAULT NULL,
  `commentaire` text,
  `date_avis` date NOT NULL,
  PRIMARY KEY (`pseudo_client`,`pseudo_cuisinier`),
  KEY `pseudo_cuisinier` (`pseudo_cuisinier`),
  CONSTRAINT `avis_post_commande_ibfk_1` FOREIGN KEY (`pseudo_client`) REFERENCES `client_individuel` (`pseudo_client`),
  CONSTRAINT `avis_post_commande_ibfk_2` FOREIGN KEY (`pseudo_cuisinier`) REFERENCES `cuisinier` (`pseudo_cuisinier`),
  CONSTRAINT `avis_post_commande_chk_1` CHECK ((`nb_etoile` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avis_post_commande`
--

LOCK TABLES `avis_post_commande` WRITE;
/*!40000 ALTER TABLE `avis_post_commande` DISABLE KEYS */;
INSERT INTO `avis_post_commande` VALUES ('client01','cuisinier01',5,'Excellente cuisine !','2025-03-03'),('client02','cuisinier02',4,'Bonne pizza, mais un peu trop cuite.','2025-03-03');
/*!40000 ALTER TABLE `avis_post_commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_individuel`
--

DROP TABLE IF EXISTS `client_individuel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_individuel` (
  `pseudo_client` varchar(50) NOT NULL,
  `pref_alimentaire` varchar(100) DEFAULT NULL,
  `telephone` varchar(14) NOT NULL,
  PRIMARY KEY (`pseudo_client`),
  UNIQUE KEY `telephone` (`telephone`),
  CONSTRAINT `client_individuel_ibfk_1` FOREIGN KEY (`telephone`) REFERENCES `individu` (`telephone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_individuel`
--

LOCK TABLES `client_individuel` WRITE;
/*!40000 ALTER TABLE `client_individuel` DISABLE KEYS */;
INSERT INTO `client_individuel` VALUES ('client01','Végétarien','0601020304'),('client02','Omnivore','0612345678');
/*!40000 ALTER TABLE `client_individuel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commande` (
  `id_commande` int NOT NULL AUTO_INCREMENT,
  `date_commande` date NOT NULL,
  `prix_total` decimal(10,2) DEFAULT NULL,
  `statut` enum('En attente','Payé','Annulé') NOT NULL,
  `paiement` enum('Carte','Espèces','Paypal') NOT NULL,
  `historique` enum('Commande en préparation','Commande confirmée') NOT NULL,
  `pseudo_client` varchar(50) DEFAULT NULL,
  `id_entreprise` int DEFAULT NULL,
  PRIMARY KEY (`id_commande`),
  KEY `pseudo_client` (`pseudo_client`),
  KEY `id_entreprise` (`id_entreprise`),
  CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`pseudo_client`) REFERENCES `client_individuel` (`pseudo_client`),
  CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`id_entreprise`) REFERENCES `entreprise` (`id_entreprise`),
  CONSTRAINT `commande_chk_1` CHECK ((`prix_total` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande`
--

LOCK TABLES `commande` WRITE;
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;
INSERT INTO `commande` VALUES (1,'2025-03-01',25.50,'Payé','Carte','Commande confirmée','client01',1),(2,'2025-03-02',40.00,'En attente','Espèces','Commande en préparation','client02',2);
/*!40000 ALTER TABLE `commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `composée`
--

DROP TABLE IF EXISTS `composée`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `composée` (
  `id_ingredient` int NOT NULL,
  `id_recette` int NOT NULL,
  PRIMARY KEY (`id_ingredient`,`id_recette`),
  KEY `id_recette` (`id_recette`),
  CONSTRAINT `composée_ibfk_1` FOREIGN KEY (`id_ingredient`) REFERENCES `ingrédient` (`id_ingredient`),
  CONSTRAINT `composée_ibfk_2` FOREIGN KEY (`id_recette`) REFERENCES `recette` (`id_recette`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `composée`
--

LOCK TABLES `composée` WRITE;
/*!40000 ALTER TABLE `composée` DISABLE KEYS */;
INSERT INTO `composée` VALUES (1,1),(2,1),(4,1),(5,1),(7,1),(10,1),(12,1),(1,2),(2,2),(4,2),(6,2),(7,2),(8,2),(10,2),(11,2),(13,2),(14,2),(1,3),(5,3),(6,3),(7,3),(11,3);
/*!40000 ALTER TABLE `composée` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contient`
--

DROP TABLE IF EXISTS `contient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contient` (
  `id_plat` int NOT NULL,
  `id_commande` int NOT NULL,
  PRIMARY KEY (`id_plat`,`id_commande`),
  KEY `id_commande` (`id_commande`),
  CONSTRAINT `contient_ibfk_1` FOREIGN KEY (`id_plat`) REFERENCES `plat` (`id_plat`),
  CONSTRAINT `contient_ibfk_2` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contient`
--

LOCK TABLES `contient` WRITE;
/*!40000 ALTER TABLE `contient` DISABLE KEYS */;
INSERT INTO `contient` VALUES (11,1),(5,2);
/*!40000 ALTER TABLE `contient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuisinier`
--

DROP TABLE IF EXISTS `cuisinier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuisinier` (
  `pseudo_cuisinier` varchar(50) NOT NULL,
  `spe_cuisine` varchar(50) NOT NULL,
  `annee_exp` int DEFAULT NULL,
  `certif` varchar(50) DEFAULT NULL,
  `note_moyenne` decimal(3,2) DEFAULT NULL,
  `nb_livraison` int DEFAULT '0',
  `telephone` varchar(14) NOT NULL,
  PRIMARY KEY (`pseudo_cuisinier`),
  UNIQUE KEY `telephone` (`telephone`),
  CONSTRAINT `cuisinier_ibfk_1` FOREIGN KEY (`telephone`) REFERENCES `individu` (`telephone`),
  CONSTRAINT `cuisinier_chk_1` CHECK ((`annee_exp` >= 0)),
  CONSTRAINT `cuisinier_chk_2` CHECK ((`note_moyenne` between 0 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuisinier`
--

LOCK TABLES `cuisinier` WRITE;
/*!40000 ALTER TABLE `cuisinier` DISABLE KEYS */;
INSERT INTO `cuisinier` VALUES ('cuisinier01','Cuisine française',5,'CAP Cuisine',4.50,10,'0601020304'),('cuisinier02','Cuisine italienne',3,'Baccalauréat Cuisine',4.20,15,'0612345678');
/*!40000 ALTER TABLE `cuisinier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entreprise`
--

DROP TABLE IF EXISTS `entreprise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entreprise` (
  `id_entreprise` int NOT NULL AUTO_INCREMENT,
  `nom_entreprise` varchar(100) NOT NULL,
  `SIRET` varchar(14) NOT NULL,
  `mail_entreprise` varchar(100) NOT NULL,
  `tel_entreprise` varchar(14) NOT NULL,
  PRIMARY KEY (`id_entreprise`),
  UNIQUE KEY `SIRET` (`SIRET`),
  UNIQUE KEY `mail_entreprise` (`mail_entreprise`),
  UNIQUE KEY `tel_entreprise` (`tel_entreprise`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entreprise`
--

LOCK TABLES `entreprise` WRITE;
/*!40000 ALTER TABLE `entreprise` DISABLE KEYS */;
INSERT INTO `entreprise` VALUES (1,'Restaurant Max','12345678901234','contact@restaurantmax.com','0145123456'),(2,'Café Alice','98765432109876','contact@cafalice.com','0145765432');
/*!40000 ALTER TABLE `entreprise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fait`
--

DROP TABLE IF EXISTS `fait`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fait` (
  `pseudo_cuisinier` varchar(50) NOT NULL,
  `id_livraison` int NOT NULL,
  PRIMARY KEY (`pseudo_cuisinier`,`id_livraison`),
  KEY `id_livraison` (`id_livraison`),
  CONSTRAINT `fait_ibfk_1` FOREIGN KEY (`pseudo_cuisinier`) REFERENCES `cuisinier` (`pseudo_cuisinier`),
  CONSTRAINT `fait_ibfk_2` FOREIGN KEY (`id_livraison`) REFERENCES `livraison` (`id_livraison`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fait`
--

LOCK TABLES `fait` WRITE;
/*!40000 ALTER TABLE `fait` DISABLE KEYS */;
INSERT INTO `fait` VALUES ('cuisinier01',1),('cuisinier02',2);
/*!40000 ALTER TABLE `fait` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `individu`
--

DROP TABLE IF EXISTS `individu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `individu` (
  `telephone` varchar(14) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Mot_de_passe` varchar(255) NOT NULL,
  PRIMARY KEY (`telephone`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `individu`
--

LOCK TABLES `individu` WRITE;
/*!40000 ALTER TABLE `individu` DISABLE KEYS */;
INSERT INTO `individu` VALUES ('0601020304','Maxence','Tessier','maxence.tessier@example.com','password123'),('0612345678','Alice','Dupont','alice.dupont@example.com','password456'),('0698765432','Bob','Martin','bob.martin@example.com','password789');
/*!40000 ALTER TABLE `individu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrédient`
--

DROP TABLE IF EXISTS `ingrédient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingrédient` (
  `id_ingredient` int NOT NULL AUTO_INCREMENT,
  `nom_ingredient` varchar(50) NOT NULL,
  PRIMARY KEY (`id_ingredient`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrédient`
--

LOCK TABLES `ingrédient` WRITE;
/*!40000 ALTER TABLE `ingrédient` DISABLE KEYS */;
INSERT INTO `ingrédient` VALUES (1,'Tomate'),(2,'Fromage'),(3,'Poulet'),(4,'Oignon'),(5,'Ail'),(6,'Viande hachée'),(7,'Crème fraîche'),(8,'Pâte feuilletée'),(9,'Farine'),(10,'Œuf'),(11,'Riz'),(12,'Haricot rouge'),(13,'Saumon'),(14,'Crevettes');
/*!40000 ALTER TABLE `ingrédient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livraison`
--

DROP TABLE IF EXISTS `livraison`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livraison` (
  `id_livraison` int NOT NULL AUTO_INCREMENT,
  `distance_km` decimal(10,2) DEFAULT NULL,
  `temps_estime` int DEFAULT NULL,
  `chemin_suivi` varchar(255) DEFAULT NULL,
  `statut` enum('En cours','Livré','Annulé') NOT NULL,
  PRIMARY KEY (`id_livraison`),
  CONSTRAINT `livraison_chk_1` CHECK ((`distance_km` >= 0)),
  CONSTRAINT `livraison_chk_2` CHECK ((`temps_estime` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livraison`
--

LOCK TABLES `livraison` WRITE;
/*!40000 ALTER TABLE `livraison` DISABLE KEYS */;
INSERT INTO `livraison` VALUES (1,5.20,30,'Chemin de la rue X, rue Y','En cours'),(2,3.80,25,'Chemin de la rue A, rue B','Livré'),(3,3.40,5,'Chemin de la rue A, rue X','En cours'),(4,3.70,8,'Chemin de la rue J, rue G','En cours'),(5,5.40,74,'Chemin de la rue K, rue H','Livré');
/*!40000 ALTER TABLE `livraison` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiement`
--

DROP TABLE IF EXISTS `paiement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiement` (
  `id_paiement` int NOT NULL AUTO_INCREMENT,
  `montant` decimal(10,2) DEFAULT NULL,
  `moyen_paiement` enum('Carte','Espèces','Paypal') NOT NULL,
  `date_paiement` date NOT NULL,
  `id_commande` int NOT NULL,
  PRIMARY KEY (`id_paiement`),
  KEY `id_commande` (`id_commande`),
  CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`),
  CONSTRAINT `paiement_chk_1` CHECK ((`montant` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiement`
--

LOCK TABLES `paiement` WRITE;
/*!40000 ALTER TABLE `paiement` DISABLE KEYS */;
INSERT INTO `paiement` VALUES (3,25.50,'Carte','2025-03-01',1),(4,40.00,'Espèces','2025-03-02',2);
/*!40000 ALTER TABLE `paiement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plat`
--

DROP TABLE IF EXISTS `plat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plat` (
  `id_plat` int NOT NULL AUTO_INCREMENT,
  `nom_plat` varchar(50) NOT NULL,
  `prix` decimal(10,2) DEFAULT NULL,
  `date_fabrication` date NOT NULL,
  `date_peremption` date NOT NULL,
  `quantite` int DEFAULT NULL,
  `pseudo_cuisinier` varchar(50) NOT NULL,
  `id_recette` int NOT NULL,
  PRIMARY KEY (`id_plat`),
  KEY `pseudo_cuisinier` (`pseudo_cuisinier`),
  KEY `id_recette` (`id_recette`),
  CONSTRAINT `plat_ibfk_1` FOREIGN KEY (`pseudo_cuisinier`) REFERENCES `cuisinier` (`pseudo_cuisinier`),
  CONSTRAINT `plat_ibfk_2` FOREIGN KEY (`id_recette`) REFERENCES `recette` (`id_recette`),
  CONSTRAINT `plat_chk_1` CHECK ((`prix` >= 0)),
  CONSTRAINT `plat_chk_2` CHECK ((`quantite` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plat`
--

LOCK TABLES `plat` WRITE;
/*!40000 ALTER TABLE `plat` DISABLE KEYS */;
INSERT INTO `plat` VALUES (3,'Lasagne Bolognese',15.00,'2025-03-03','2025-03-10',400,'cuisinier01',2),(5,'Pâtes Carbonara',12.50,'2025-03-05','2025-03-12',350,'cuisinier02',2),(6,'Curry de légumes',10.00,'2025-03-06','2025-03-13',320,'cuisinier02',3),(7,'Sushi saumon',18.00,'2025-03-07','2025-03-14',250,'cuisinier01',3),(8,'Poulet rôti',14.00,'2025-03-08','2025-03-15',500,'cuisinier02',2),(9,'Burger classique',11.50,'2025-03-09','2025-03-16',280,'cuisinier02',2),(10,'Tartiflette',16.00,'2025-03-10','2025-03-17',400,'cuisinier02',1),(11,'Moussaka',13.00,'2025-03-11','2025-03-18',380,'cuisinier01',3),(12,'Quiche Lorraine',9.50,'2025-03-12','2025-03-19',250,'cuisinier02',2),(13,'Sushi végétarien',17.50,'2025-03-13','2025-03-20',250,'cuisinier01',3),(15,'Chili sin carne',11.00,'2025-03-15','2025-03-22',350,'cuisinier01',1);
/*!40000 ALTER TABLE `plat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recette`
--

DROP TABLE IF EXISTS `recette`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recette` (
  `id_recette` int NOT NULL AUTO_INCREMENT,
  `regime_alimentaire` varchar(50) DEFAULT NULL,
  `nationalite` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_recette`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recette`
--

LOCK TABLES `recette` WRITE;
/*!40000 ALTER TABLE `recette` DISABLE KEYS */;
INSERT INTO `recette` VALUES (1,'Végétarien','Française','Entrée'),(2,'Omnivore','Italienne','Plat principal'),(3,'Végétarien','Indienne','Plat principal');
/*!40000 ALTER TABLE `recette` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-30 22:57:40
