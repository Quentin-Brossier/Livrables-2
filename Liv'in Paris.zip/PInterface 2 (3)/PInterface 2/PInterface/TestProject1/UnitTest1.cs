using System;
using System.Collections.Generic;
using System.Drawing;
using Xunit;

namespace projet.Tests
{
    public class GrapheTests
    {
        [Fact]
        public void ChargerStationsDepuisCSV_ChargeCorrectement()
        {
            // Arrange
            var graphe = new Graphe();
            string cheminFichier = "stations_test.csv";

            // Act
            graphe.ChargerStationsDepuisCSV(cheminFichier);

            // Assert
            Assert.NotEmpty(graphe.Noeuds);
        }

        [Fact]
        public void ChargerLignesDepuisCSV_ChargeCorrectement()
        {
            // Arrange
            var graphe = new Graphe();
            string cheminStations = "stations_test.csv";
            string cheminLignes = "lignes_test.csv";
            graphe.ChargerStationsDepuisCSV(cheminStations);

            // Act
            graphe.ChargerLignesDepuisCSV(cheminLignes);

            // Assert
            foreach (var noeud in graphe.Noeuds)
            {
                Assert.NotEmpty(noeud.Station.Lignes);
            }
        }

        [Fact]
        public void Dijkstra_TrouveCheminValide()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.ChargerStationsDepuisCSV("stations_test.csv");
            graphe.ChargerLignesDepuisCSV("lignes_test.csv");

            string start = "StationA";
            string end = "StationB";
            string closed = "StationC";

            // Act
            graphe.Dijkstra(start, end, closed, out var cheminNoeuds, out _);

            // Assert
            Assert.NotEmpty(cheminNoeuds);
            Assert.Equal(start, cheminNoeuds[0].Station.Nom);
            Assert.Equal(end, cheminNoeuds[^1].Station.Nom);
        }

        [Fact]
        public void BellmanFord_TrouveCheminValide()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.ChargerStationsDepuisCSV("stations_test.csv");
            graphe.ChargerLignesDepuisCSV("lignes_test.csv");

            string start = "StationA";
            string end = "StationB";
            string closed = "StationC";

            // Act
            graphe.BellmanFord(start, end, closed, out var cheminNoeuds, out _);

            // Assert
            Assert.NotEmpty(cheminNoeuds);
            Assert.Equal(start, cheminNoeuds[0].Station.Nom);
            Assert.Equal(end, cheminNoeuds[^1].Station.Nom);
        }

        [Fact]
        public void ConvertirCoordonnees_RetournePointCorrect()
        {
            // Arrange
            var graphe = new Graphe();
            double latitude = 48.8566;
            double longitude = 2.3522;

            // Act
            PointF point = graphe.ConvertirCoordonnees(latitude, longitude);

            // Assert
            Assert.Equal(1000, point.X, 0);
            Assert.Equal(300, point.Y, 0);
        }

        [Fact]
        public void Distance_CalculCorrect()
        {
            // Arrange
            var graphe = new Graphe();
            PointF p1 = new PointF(0, 0);
            PointF p2 = new PointF(3, 4);

            // Act
            float distance = graphe.Distance(p1, p2);

            // Assert
            Assert.Equal(5, distance, 1);
        }
    }

    public class StationTests
    {
        [Fact]
        public void Station_Initialisation_Correcte()
        {
            var station = new Station
            {
                Id = 1,
                Nom = "Ch�telet",
                Longitude = 2.347,
                Latitude = 48.858,
                Ligne = "M1",
                Lignes = new List<string> { "M1", "M4", "M7" },
                TempsDeChangement = 3
            };

            Assert.Equal(1, station.Id);
            Assert.Equal("Ch�telet", station.Nom);
            Assert.Equal(2.347, station.Longitude);
            Assert.Equal(48.858, station.Latitude);
            Assert.Equal("M1", station.Ligne);
            Assert.Contains("M4", station.Lignes);
            Assert.Equal(3, station.TempsDeChangement);
        }

        [Fact]
        public void Station_TempsDeChangement_Defaut()
        {
            var station = new Station();
            Assert.Equal(5, station.TempsDeChangement);
        }
    }

    public class VisualiseurGrapheTests
{
    [Fact]
    public void CreerVisualiseurGraphe_AvecGrapheValide_DoitInitialiserCorrectement()
    {
        var graphe = new Graphe();
        var visualiseur = new VisualiseurGraphe(graphe, 1.5f, new PointF(10, 10));

        Assert.NotNull(visualiseur);
    }

    [Fact]
    public void DessinerNoeuds_NeDoitPasPlanterAvecNoeuds()
    {
        var graphe = new Graphe();
        graphe.Noeuds.Add(new Noeud(new Station { Nom = "Bastille" }, new PointF(100, 100)));
        graphe.Noeuds.Add(new Noeud(new Station { Nom = "R�publique" }, new PointF(200, 200)));

        var visualiseur = new VisualiseurGraphe(graphe, 1.0f, new PointF(0, 0));

        using (Bitmap bmp = new Bitmap(500, 500))
        using (Graphics g = Graphics.FromImage(bmp))
        {
            var exception = Record.Exception(() => visualiseur.Dessiner(g));
            Assert.Null(exception);
        }
    }
}
}